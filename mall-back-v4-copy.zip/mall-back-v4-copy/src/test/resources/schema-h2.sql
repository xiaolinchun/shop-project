-- ============================================================
-- 接口测试用 H2（MySQL 兼容模式）表结构
-- 与 online_shop_v4.sql 保持一致，仅去掉 MySQL 专有引擎/字符集声明
-- ============================================================

DROP TABLE IF EXISTS mock_channel_txn;
DROP TABLE IF EXISTS refund_record;
DROP TABLE IF EXISTS payment_record;
DROP TABLE IF EXISTS review;
DROP TABLE IF EXISTS after_sales_order;
DROP TABLE IF EXISTS logistics_tracking;
DROP TABLE IF EXISTS logistics_provider;
DROP TABLE IF EXISTS address;
DROP TABLE IF EXISTS order_item;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS cart_item;
DROP TABLE IF EXISTS favorite;
DROP TABLE IF EXISTS product;
DROP TABLE IF EXISTS category;
DROP TABLE IF EXISTS buyer_account;
DROP TABLE IF EXISTS seller;

CREATE TABLE seller (
    username      VARCHAR(64)  NOT NULL PRIMARY KEY,
    password_hash VARCHAR(255) NOT NULL,
    token         VARCHAR(64)
);

CREATE TABLE category (
    id            INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    parent_id     INT          NOT NULL DEFAULT 0,
    category_name VARCHAR(128) NOT NULL,
    CONSTRAINT uk_parent_name UNIQUE (parent_id, category_name)
);

CREATE TABLE buyer_account (
    id                     INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username               VARCHAR(64)  NOT NULL,
    password_hash          VARCHAR(255) NOT NULL,
    phone                  VARCHAR(64)  NOT NULL,
    default_trade_location VARCHAR(255),
    token                  VARCHAR(64),
    created_at             TIMESTAMP    NOT NULL,
    CONSTRAINT uk_buyer_username UNIQUE (username),
    CONSTRAINT uk_buyer_token UNIQUE (token)
);

CREATE TABLE product (
    id            INT           NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(255)  NOT NULL,
    description   CLOB,
    image_urls    CLOB,
    price         DECIMAL(10, 2) NOT NULL,
    sale_price    DECIMAL(10, 2),
    sale_start_at TIMESTAMP,
    sale_end_at   TIMESTAMP,
    status        VARCHAR(20)   NOT NULL,
    off_reason    VARCHAR(20),
    stock         INT           NOT NULL DEFAULT 0,
    published_at  TIMESTAMP     NOT NULL,
    closed_at     TIMESTAMP,
    seller_id     VARCHAR(64)   NOT NULL,
    category_id   INT           NOT NULL,
    CONSTRAINT fk_product_seller FOREIGN KEY (seller_id) REFERENCES seller (username),
    CONSTRAINT fk_product_category FOREIGN KEY (category_id) REFERENCES category (id)
);

CREATE TABLE cart_item (
    id               INT       NOT NULL AUTO_INCREMENT PRIMARY KEY,
    buyer_account_id INT       NOT NULL,
    product_id       INT       NOT NULL,
    quantity         INT       NOT NULL DEFAULT 1,
    created_at       TIMESTAMP NOT NULL,
    updated_at       TIMESTAMP NOT NULL,
    CONSTRAINT uk_cart_buyer_product UNIQUE (buyer_account_id, product_id),
    CONSTRAINT fk_cart_buyer FOREIGN KEY (buyer_account_id) REFERENCES buyer_account (id),
    CONSTRAINT fk_cart_product FOREIGN KEY (product_id) REFERENCES product (id)
);

CREATE TABLE favorite (
    id               INT       NOT NULL AUTO_INCREMENT PRIMARY KEY,
    buyer_account_id INT       NOT NULL,
    product_id       INT       NOT NULL,
    created_at       TIMESTAMP NOT NULL,
    CONSTRAINT uk_fav_buyer_product UNIQUE (buyer_account_id, product_id),
    CONSTRAINT fk_favorite_buyer FOREIGN KEY (buyer_account_id) REFERENCES buyer_account (id),
    CONSTRAINT fk_favorite_product FOREIGN KEY (product_id) REFERENCES product (id)
);

CREATE TABLE address (
    id               INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    buyer_account_id INT          NOT NULL,
    name             VARCHAR(64)  NOT NULL,
    phone            VARCHAR(32)  NOT NULL,
    province         VARCHAR(64)  NOT NULL,
    city             VARCHAR(64)  NOT NULL,
    district         VARCHAR(64)  NOT NULL,
    detail           VARCHAR(255) NOT NULL,
    is_default       BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMP    NOT NULL,
    updated_at       TIMESTAMP    NOT NULL,
    CONSTRAINT fk_address_buyer FOREIGN KEY (buyer_account_id) REFERENCES buyer_account (id)
);

CREATE TABLE orders (
    id                 INT           NOT NULL AUTO_INCREMENT PRIMARY KEY,
    order_no           VARCHAR(32)   NOT NULL,
    status             VARCHAR(20)   NOT NULL,
    total_amount       DECIMAL(10, 2) NOT NULL,
    buyer_account_id   INT           NOT NULL,
    payment_channel    VARCHAR(20),
    paid_at            TIMESTAMP,
    address_name       VARCHAR(64)   NOT NULL,
    address_phone      VARCHAR(32)   NOT NULL,
    address_province   VARCHAR(64)   NOT NULL,
    address_city       VARCHAR(64)   NOT NULL,
    address_district   VARCHAR(64)   NOT NULL,
    address_detail     VARCHAR(255)  NOT NULL,
    logistics_provider VARCHAR(128),
    waybill_no         VARCHAR(64),
    created_at         TIMESTAMP     NOT NULL,
    updated_at         TIMESTAMP     NOT NULL,
    CONSTRAINT uk_order_no UNIQUE (order_no),
    CONSTRAINT fk_order_buyer FOREIGN KEY (buyer_account_id) REFERENCES buyer_account (id)
);

CREATE TABLE order_item (
    id           INT           NOT NULL AUTO_INCREMENT PRIMARY KEY,
    order_id     INT           NOT NULL,
    product_id   INT           NOT NULL,
    product_name VARCHAR(255)  NOT NULL,
    unit_price   DECIMAL(10, 2) NOT NULL,
    quantity     INT           NOT NULL,
    CONSTRAINT fk_item_order FOREIGN KEY (order_id) REFERENCES orders (id),
    CONSTRAINT fk_item_product FOREIGN KEY (product_id) REFERENCES product (id)
);

CREATE TABLE payment_record (
    id             INT           NOT NULL AUTO_INCREMENT PRIMARY KEY,
    payment_no     VARCHAR(32)   NOT NULL,
    order_no       VARCHAR(32)   NOT NULL,
    order_id       INT           NOT NULL,
    channel        VARCHAR(20)   NOT NULL,
    amount         DECIMAL(10, 2) NOT NULL,
    status         VARCHAR(20)   NOT NULL,
    channel_txn_no VARCHAR(64),
    paid_at        TIMESTAMP,
    created_at     TIMESTAMP     NOT NULL,
    CONSTRAINT uk_payment_no UNIQUE (payment_no),
    CONSTRAINT uk_channel_txn_no UNIQUE (channel_txn_no),
    CONSTRAINT fk_payment_order FOREIGN KEY (order_id) REFERENCES orders (id)
);

CREATE TABLE refund_record (
    id             INT           NOT NULL AUTO_INCREMENT PRIMARY KEY,
    refund_no      VARCHAR(32)   NOT NULL,
    payment_no     VARCHAR(32)   NOT NULL,
    after_sales_no VARCHAR(32),
    order_id       INT           NOT NULL,
    amount         DECIMAL(10, 2) NOT NULL,
    channel        VARCHAR(20)   NOT NULL,
    status         VARCHAR(20)   NOT NULL,
    created_at     TIMESTAMP     NOT NULL,
    CONSTRAINT uk_refund_no UNIQUE (refund_no),
    CONSTRAINT fk_refund_order FOREIGN KEY (order_id) REFERENCES orders (id)
);

CREATE TABLE after_sales_order (
    id                  INT           NOT NULL AUTO_INCREMENT PRIMARY KEY,
    after_sales_no      VARCHAR(32)   NOT NULL,
    order_id            INT           NOT NULL,
    order_item_id       INT           NOT NULL,
    buyer_account_id    INT           NOT NULL,
    product_id          INT           NOT NULL,
    product_name        VARCHAR(255)  NOT NULL,
    title               VARCHAR(128)  NOT NULL,
    description         VARCHAR(1000) NOT NULL,
    images              CLOB,
    status              VARCHAR(20)   NOT NULL,
    result              VARCHAR(32),
    result_at           TIMESTAMP,
    return_waybill_no   VARCHAR(64),
    exchange_waybill_no VARCHAR(64),
    created_at          TIMESTAMP     NOT NULL,
    updated_at          TIMESTAMP     NOT NULL,
    CONSTRAINT uk_after_sales_no UNIQUE (after_sales_no),
    CONSTRAINT fk_as_order FOREIGN KEY (order_id) REFERENCES orders (id),
    CONSTRAINT fk_as_item FOREIGN KEY (order_item_id) REFERENCES order_item (id)
);

CREATE TABLE review (
    id               INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    order_id         INT          NOT NULL,
    order_item_id    INT          NOT NULL,
    product_id       INT          NOT NULL,
    buyer_account_id INT          NOT NULL,
    rating           INT          NOT NULL,
    content          VARCHAR(200),
    images           CLOB,
    created_at       TIMESTAMP    NOT NULL,
    CONSTRAINT uk_review_item UNIQUE (order_item_id),
    CONSTRAINT fk_review_order FOREIGN KEY (order_id) REFERENCES orders (id),
    CONSTRAINT fk_review_item FOREIGN KEY (order_item_id) REFERENCES order_item (id)
);

CREATE TABLE logistics_provider (
    id         INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(128) NOT NULL,
    created_at TIMESTAMP    NOT NULL,
    CONSTRAINT uk_provider_name UNIQUE (name)
);

CREATE TABLE logistics_tracking (
    id          INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    order_id    INT          NOT NULL,
    waybill_no  VARCHAR(64)  NOT NULL,
    status      VARCHAR(32)  NOT NULL,
    description VARCHAR(255),
    tracked_at  TIMESTAMP    NOT NULL,
    created_at  TIMESTAMP    NOT NULL,
    CONSTRAINT fk_tracking_order FOREIGN KEY (order_id) REFERENCES orders (id)
);

CREATE TABLE mock_channel_txn (
    id             INT           NOT NULL AUTO_INCREMENT PRIMARY KEY,
    channel_txn_no VARCHAR(64)   NOT NULL,
    payment_no     VARCHAR(32)   NOT NULL,
    channel        VARCHAR(20)   NOT NULL,
    amount         DECIMAL(10, 2) NOT NULL,
    mock_result    VARCHAR(20)   NOT NULL,
    callback_at    TIMESTAMP     NOT NULL,
    created_at     TIMESTAMP     NOT NULL,
    CONSTRAINT uk_txn_no UNIQUE (channel_txn_no)
);
