-- ============================================================
-- 接口测试种子数据（与 online_shop_v4.sql 的演示数据保持一致）
-- 说明：账号密码哈希在测试基类中通过 BCrypt 重新写入，
--       buyer01 / 12345678，seller01 / seller123
-- ============================================================

INSERT INTO seller (username, password_hash) VALUES
    ('seller01', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi');

INSERT INTO category (id, parent_id, category_name) VALUES
    (1, 0, '手机数码'),
    (2, 0, '电脑办公'),
    (3, 0, '家用电器'),
    (5, 1, '手机'),
    (6, 2, '笔记本电脑'),
    (7, 1, '平板电脑'),
    (8, 1, '耳机'),
    (9, 3, '冰箱');

INSERT INTO buyer_account
    (id, username, password_hash, phone, default_trade_location, token, created_at)
VALUES
    (1, 'buyer01', '$2a$10$B7ouTG/9ejNcGFdagr5qwuAgZsPMrsAlqSDhEk7CsigQCJTaBScjO',
     '13800138000', '图书馆正门', NULL, '2026-10-10 20:15:00');

INSERT INTO product
    (id, name, description, image_urls, price, sale_price, sale_start_at, sale_end_at,
     status, off_reason, stock, published_at, closed_at, seller_id, category_id)
VALUES
    (1, 'iPhone 15', '<p>全新未拆封，支持全国联保。</p>',
     '["https://cdn.example.com/iphone15-1.jpg","https://cdn.example.com/iphone15-2.jpg"]',
     5999.00, NULL, NULL, NULL, 'ONLINE', NULL, 10, '2026-10-01 10:00:00', NULL, 'seller01', 5),
    (2, '小米14 Ultra', '<p>徕卡影像旗舰。</p>', '["https://cdn.example.com/mi14-1.jpg"]',
     6499.00, NULL, NULL, NULL, 'ONLINE', NULL, 5, '2026-10-02 14:30:00', NULL, 'seller01', 5),
    (3, 'MacBook Air M3', '<p>13 英寸，M3 芯片。</p>', '["https://cdn.example.com/mba-1.jpg"]',
     8999.00, NULL, NULL, NULL, 'ONLINE', NULL, 3, '2026-10-03 09:00:00', NULL, 'seller01', 6),
    (4, 'iPad Air 5', '<p>M1 芯片，轻微使用痕迹。</p>', '["https://cdn.example.com/ipad-1.jpg"]',
     3899.00, NULL, NULL, NULL, 'OFFLINE', 'STOCK_OUT', 0, '2026-09-01 10:00:00', '2026-09-30 22:00:00', 'seller01', 7),
    (5, '二手山地自行车', '<p>九成新，变速灵敏。</p>', '["/uploads/a1b2c3.png"]',
     199.00, NULL, NULL, NULL, 'ONLINE', NULL, 5, '2026-11-01 10:00:00', NULL, 'seller01', 5),
    (6, 'AirPods Pro 2', '<p>主动降噪蓝牙耳机，在保。</p>', NULL,
     1599.00, NULL, NULL, NULL, 'ONLINE', NULL, 20, '2026-10-05 20:00:00', NULL, 'seller01', 8);

INSERT INTO address
    (id, buyer_account_id, name, phone, province, city, district, detail, is_default, created_at, updated_at)
VALUES
    (1, 1, '张三', '13800138000', '广东', '深圳', '南山区', '科技园路 1 号', TRUE, '2026-10-11 09:00:00', '2026-10-11 09:00:00'),
    (2, 1, '李四', '13900139000', '北京', '北京', '海淀区', '中关村大街 5 号', FALSE, '2026-10-12 10:00:00', '2026-10-12 10:00:00');

INSERT INTO logistics_provider (id, name, created_at) VALUES
    (1, '顺丰速运', '2026-11-01 10:00:00'),
    (2, '京东物流', '2026-11-01 10:05:00');

INSERT INTO orders
    (id, order_no, status, total_amount, buyer_account_id, payment_channel, paid_at,
     address_name, address_phone, address_province, address_city, address_district, address_detail,
     logistics_provider, waybill_no, created_at, updated_at)
VALUES
    (1, '20261101-0001', 'COMPLETED', 159.00, 1, 'ALIPAY', '2026-11-01 09:05:00',
     '张三', '13800138000', '广东', '深圳', '南山区', '科技园路 1 号',
     '顺丰速运', 'SF1000000001', '2026-11-01 09:00:00', '2026-11-03 18:00:00'),
    (2, '20261102-0001', 'SHIPPING', 1599.00, 1, 'WECHAT_PAY', '2026-11-02 10:05:00',
     '李四', '13900139000', '北京', '北京', '海淀区', '中关村大街 5 号',
     '顺丰速运', 'SF1000000002', '2026-11-02 10:00:00', '2026-11-04 09:00:00'),
    (3, '20261103-0001', 'COMPLETED', 6499.00, 1, 'BANK_CARD', '2026-11-03 11:05:00',
     '张三', '13800138000', '广东', '深圳', '南山区', '科技园路 1 号',
     '京东物流', 'JD1000000003', '2026-11-03 11:00:00', '2026-11-05 18:00:00');

INSERT INTO order_item (id, order_id, product_id, product_name, unit_price, quantity) VALUES
    (1, 1, 5, '二手山地自行车', 159.00, 1),
    (2, 2, 6, 'AirPods Pro 2', 1599.00, 1),
    (3, 3, 2, '小米14 Ultra', 6499.00, 1);

INSERT INTO payment_record
    (id, payment_no, order_no, order_id, channel, amount, status, channel_txn_no, paid_at, created_at)
VALUES
    (1, 'PAY202611010001', '20261101-0001', 1, 'ALIPAY', 159.00, 'SUCCESS', 'MOCK20261101090500', '2026-11-01 09:05:00', '2026-11-01 09:04:00'),
    (2, 'PAY202611020001', '20261102-0001', 2, 'WECHAT_PAY', 1599.00, 'SUCCESS', 'MOCK20261102100500', '2026-11-02 10:05:00', '2026-11-02 10:04:00'),
    (3, 'PAY202611030001', '20261103-0001', 3, 'BANK_CARD', 6499.00, 'SUCCESS', 'MOCK20261103110500', '2026-11-03 11:05:00', '2026-11-03 11:04:00');

INSERT INTO review
    (id, order_id, order_item_id, product_id, buyer_account_id, rating, content, images, created_at)
VALUES
    (1, 1, 1, 5, 1, 5, '骑行顺畅，成色不错，卖家发货也快', '[]', '2026-11-03 20:00:00');

INSERT INTO logistics_tracking (order_id, waybill_no, status, description, tracked_at, created_at) VALUES
    (2, 'SF1000000002', 'IN_TRANSIT', '快件已到达北京转运中心', '2026-11-05 09:12:00', '2026-11-05 09:13:00'),
    (2, 'SF1000000002', 'PICKED_UP', '顺丰速运已揽收', '2026-11-04 18:30:00', '2026-11-04 18:31:00');

-- 手工插入固定主键后重置自增序列，避免后续接口写入主键冲突
ALTER TABLE buyer_account ALTER COLUMN id RESTART WITH 100;
ALTER TABLE category ALTER COLUMN id RESTART WITH 100;
ALTER TABLE product ALTER COLUMN id RESTART WITH 100;
ALTER TABLE address ALTER COLUMN id RESTART WITH 100;
ALTER TABLE orders ALTER COLUMN id RESTART WITH 100;
ALTER TABLE order_item ALTER COLUMN id RESTART WITH 100;
ALTER TABLE payment_record ALTER COLUMN id RESTART WITH 100;
ALTER TABLE refund_record ALTER COLUMN id RESTART WITH 100;
ALTER TABLE after_sales_order ALTER COLUMN id RESTART WITH 100;
ALTER TABLE review ALTER COLUMN id RESTART WITH 100;
ALTER TABLE logistics_provider ALTER COLUMN id RESTART WITH 100;
ALTER TABLE logistics_tracking ALTER COLUMN id RESTART WITH 100;
ALTER TABLE mock_channel_txn ALTER COLUMN id RESTART WITH 100;
ALTER TABLE cart_item ALTER COLUMN id RESTART WITH 100;
ALTER TABLE favorite ALTER COLUMN id RESTART WITH 100;
