package com.shop.online_shop.support;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

/**
 * 接口测试基类：
 * - 启动完整 Spring 上下文（Controller + Service + MyBatis Mapper + 拦截器 + 全局异常处理）
 * - 数据源使用 H2（MySQL 兼容模式），无需本地 MySQL
 * - 每个测试方法运行在事务中，结束后回滚，保证用例互不影响
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
public abstract class ApiTestSupport {

    protected static final String BUYER_USERNAME = "buyer01";
    protected static final String BUYER_PASSWORD = "12345678";
    protected static final String SELLER_USERNAME = "seller01";
    protected static final String SELLER_PASSWORD = "seller123";

    /** 种子商品 ID */
    protected static final int PRODUCT_IPHONE = 1;
    protected static final int PRODUCT_MI14 = 2;
    protected static final int PRODUCT_MACBOOK = 3;
    protected static final int PRODUCT_IPAD_OFFLINE = 4;
    protected static final int PRODUCT_BIKE = 5;
    protected static final int PRODUCT_AIRPODS = 6;

    private static final BCryptPasswordEncoder ENCODER = new BCryptPasswordEncoder();
    private static final String BUYER_HASH = ENCODER.encode(BUYER_PASSWORD);
    private static final String SELLER_HASH = ENCODER.encode(SELLER_PASSWORD);

    @Autowired
    protected MockMvc mockMvc;

    @Autowired
    protected ObjectMapper objectMapper;

    @Autowired
    protected JdbcTemplate jdbcTemplate;

    @BeforeEach
    void resetSeedCredentials() {
        jdbcTemplate.update("UPDATE buyer_account SET password_hash = ?, token = NULL WHERE username = ?",
                BUYER_HASH, BUYER_USERNAME);
        jdbcTemplate.update("UPDATE seller SET password_hash = ?, token = NULL WHERE username = ?",
                SELLER_HASH, SELLER_USERNAME);
    }

    // ===================== 请求构造 =====================

    protected ResultActions getJson(String url) throws Exception {
        return mockMvc.perform(get(url));
    }

    protected ResultActions postJson(String url, Object body) throws Exception {
        return mockMvc.perform(post(url)
                .contentType(MediaType.APPLICATION_JSON)
                .content(toJson(body)));
    }

    protected ResultActions putJson(String url, Object body) throws Exception {
        return mockMvc.perform(put(url)
                .contentType(MediaType.APPLICATION_JSON)
                .content(toJson(body)));
    }

    protected ResultActions deleteReq(String url) throws Exception {
        return mockMvc.perform(delete(url));
    }

    protected ResultActions authGet(String url, String token) throws Exception {
        return mockMvc.perform(withToken(get(url), token));
    }

    protected ResultActions authPost(String url, String token, Object body) throws Exception {
        MockHttpServletRequestBuilder builder = post(url).contentType(MediaType.APPLICATION_JSON);
        if (body != null) {
            builder.content(toJson(body));
        }
        return mockMvc.perform(withToken(builder, token));
    }

    protected ResultActions authPostNoBody(String url, String token) throws Exception {
        return mockMvc.perform(withToken(post(url), token));
    }

    protected ResultActions authPut(String url, String token, Object body) throws Exception {
        return mockMvc.perform(withToken(put(url)
                .contentType(MediaType.APPLICATION_JSON)
                .content(toJson(body)), token));
    }

    protected ResultActions authPutNoBody(String url, String token) throws Exception {
        return mockMvc.perform(withToken(put(url), token));
    }

    protected ResultActions authDelete(String url, String token) throws Exception {
        return mockMvc.perform(withToken(delete(url), token));
    }

    private MockHttpServletRequestBuilder withToken(MockHttpServletRequestBuilder builder, String token) {
        return token == null ? builder : builder.header("Authorization", "Bearer " + token);
    }

    protected String toJson(Object value) throws Exception {
        return objectMapper.writeValueAsString(value);
    }

    protected JsonNode body(ResultActions actions) throws Exception {
        MvcResult result = actions.andReturn();
        String content = result.getResponse().getContentAsString(StandardCharsets.UTF_8);
        assertThat(content).as("响应体不应为空").isNotBlank();
        return objectMapper.readTree(content);
    }

    /** 断言业务成功（code = 200）并返回 data 节点 */
    protected JsonNode okData(ResultActions actions) throws Exception {
        JsonNode root = body(actions);
        assertThat(root.path("code").asInt()).as("业务响应码: %s", root).isEqualTo(200);
        return root.path("data");
    }

    /** 断言业务失败并返回提示信息 */
    protected String failMsg(ResultActions actions) throws Exception {
        JsonNode root = body(actions);
        assertThat(root.path("code").asInt()).as("业务响应码: %s", root).isEqualTo(500);
        return root.path("msg").asText();
    }

    // ===================== 业务辅助 =====================

    protected Map<String, Object> credentials(String username, String password) {
        Map<String, Object> body = new HashMap<>();
        body.put("username", username);
        body.put("password", password);
        return body;
    }

    /** 买家登录，返回 token */
    protected String loginBuyer() throws Exception {
        return loginBuyer(BUYER_USERNAME, BUYER_PASSWORD);
    }

    protected String loginBuyer(String username, String password) throws Exception {
        JsonNode data = okData(postJson("/api/buyer/login", credentials(username, password)));
        return data.asText();
    }

    /** 卖家登录，返回 token */
    protected String loginSeller() throws Exception {
        JsonNode data = okData(postJson("/api/seller/login", credentials(SELLER_USERNAME, SELLER_PASSWORD)));
        return data.asText();
    }

    /** 注册新买家并返回 token */
    protected String registerBuyer(String username) throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("username", username);
        body.put("password", "12345678");
        body.put("phone", "13900001111");
        return okData(postJson("/api/buyer/register", body)).asText();
    }

    /** 商品详情页直接下单，返回订单节点 */
    protected JsonNode createOrder(int productId, int quantity) throws Exception {
        return createOrder(loginBuyer(), productId, quantity);
    }

    protected JsonNode createOrder(String buyerToken, int productId, int quantity) throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("productId", productId);
        body.put("quantity", quantity);
        return okData(authPost("/api/buyer/order", buyerToken, body));
    }

    /** 发起支付，返回支付单节点 */
    protected JsonNode initiatePay(String buyerToken, int orderId, String channel) throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("channel", channel);
        return okData(authPost("/api/buyer/order/" + orderId + "/pay", buyerToken, body));
    }

    /** 模拟渠道回调 */
    protected JsonNode notifyPayment(String paymentNo, String channel, String txnNo, String result) throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("paymentNo", paymentNo);
        body.put("channel", channel);
        body.put("channelTxnNo", txnNo);
        body.put("result", result);
        body.put("paidAt", "2026-11-25 10:00:00");
        return okData(postJson("/api/payment/notify", body));
    }

    /** 创建一笔已支付（PAID）订单，返回订单节点 */
    protected JsonNode createPaidOrder(int productId, int quantity) throws Exception {
        String token = loginBuyer();
        JsonNode order = createOrder(token, productId, quantity);
        int orderId = order.path("id").asInt();
        String paymentNo = initiatePay(token, orderId, "ALIPAY").path("paymentNo").asText();
        notifyPayment(paymentNo, "ALIPAY", "TXN" + orderId + "-" + System.nanoTime(), "SUCCESS");
        return order;
    }

    /** 从买家订单历史中读取指定订单 */
    protected JsonNode findHistoryOrder(String buyerToken, int orderId) throws Exception {
        JsonNode data = okData(authGet("/api/buyer/order/history?page=1", buyerToken));
        for (JsonNode order : data.path("list")) {
            if (order.path("id").asInt() == orderId) {
                return order;
            }
        }
        throw new AssertionError("订单历史中未找到订单 id=" + orderId);
    }

    /** 读取购物车列表 */
    protected List<JsonNode> cartItems(String buyerToken) throws Exception {
        JsonNode data = okData(authGet("/api/buyer/cart", buyerToken));
        return toList(data);
    }

    protected List<JsonNode> toList(JsonNode array) {
        java.util.ArrayList<JsonNode> list = new java.util.ArrayList<>();
        array.forEach(list::add);
        return list;
    }
}
