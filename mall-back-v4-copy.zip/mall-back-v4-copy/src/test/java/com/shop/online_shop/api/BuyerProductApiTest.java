package com.shop.online_shop.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.shop.online_shop.support.ApiTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * 买家端商品浏览接口测试（需求 2.1 – 2.4、2.18、2.30）
 */
@DisplayName("买家端-商品浏览接口")
class BuyerProductApiTest extends ApiTestSupport {

    @Test
    @DisplayName("2.1 浏览当前最新在售商品")
    void currentProduct_returnsLatestOnline() throws Exception {
        JsonNode data = okData(getJson("/api/buyer/product/current"));

        assertThat(data.path("name").asText()).isEqualTo("二手山地自行车");
        assertThat(data.path("status").asText()).isEqualTo("ONLINE");
        assertThat(data.path("availableQuantity").asInt()).isEqualTo(5);
        assertThat(data.path("reviewCount").asInt()).isEqualTo(1);
    }

    @Test
    @DisplayName("2.2 商品列表默认分页只返回在售商品")
    void productList_returnsOnlineProductsWithPaging() throws Exception {
        JsonNode data = okData(getJson("/api/buyer/product/list"));

        assertThat(data.path("total").asInt()).isEqualTo(5);
        assertThat(data.path("page").asInt()).isEqualTo(1);
        assertThat(data.path("size").asInt()).isEqualTo(10);
        assertThat(data.path("list")).hasSize(5);
        data.path("list").forEach(item ->
                assertThat(item.path("status").asText()).isEqualTo("ONLINE"));
    }

    @Test
    @DisplayName("2.2 商品列表按关键词搜索")
    void productList_filtersByKeyword() throws Exception {
        JsonNode data = okData(getJson("/api/buyer/product/list?keyword=小米"));

        assertThat(data.path("total").asInt()).isEqualTo(1);
        assertThat(data.path("list").get(0).path("name").asText()).isEqualTo("小米14 Ultra");
    }

    @Test
    @DisplayName("2.2 商品列表按分类筛选")
    void productList_filtersByCategory() throws Exception {
        JsonNode data = okData(getJson("/api/buyer/product/list?categoryId=5"));

        assertThat(data.path("total").asInt()).isEqualTo(3);
    }

    @Test
    @DisplayName("2.2 商品列表按发布时间正序排序")
    void productList_sortsByTimeAsc() throws Exception {
        JsonNode data = okData(getJson("/api/buyer/product/list?sort=TIME_ASC"));

        assertThat(data.path("list").get(0).path("name").asText()).isEqualTo("iPhone 15");
    }

    @Test
    @DisplayName("2.2 页码非法时返回参数校验提示")
    void productList_rejectsInvalidPage() throws Exception {
        assertThat(failMsg(getJson("/api/buyer/product/list?page=0")))
                .isEqualTo("页码必须大于等于1");
    }

    @Test
    @DisplayName("2.3 商品搜索缺少关键词时提示缺少参数")
    void searchProducts_requiresKeyword() throws Exception {
        assertThat(failMsg(getJson("/api/buyer/product/search")))
                .isEqualTo("缺少必要参数：keyword");
    }

    @Test
    @DisplayName("2.3 商品搜索返回命中结果")
    void searchProducts_returnsMatches() throws Exception {
        JsonNode data = okData(getJson("/api/buyer/product/search?keyword=AirPods"));

        assertThat(data.path("total").asInt()).isEqualTo(1);
        assertThat(data.path("list").get(0).path("name").asText()).isEqualTo("AirPods Pro 2");
    }

    @Test
    @DisplayName("2.4 商品详情返回聚合评分与图片主图")
    void productDetail_returnsDetail() throws Exception {
        JsonNode data = okData(getJson("/api/buyer/product/1"));

        assertThat(data.path("name").asText()).isEqualTo("iPhone 15");
        assertThat(data.path("mainImageUrl").asText()).isEqualTo("https://cdn.example.com/iphone15-1.jpg");
        assertThat(data.path("categoryName").asText()).isEqualTo("手机数码 / 手机");
    }

    @Test
    @DisplayName("2.4 已下架商品买家不可访问")
    void productDetail_rejectsOfflineProduct() throws Exception {
        assertThat(failMsg(getJson("/api/buyer/product/4"))).isEqualTo("商品已下架");
    }

    @Test
    @DisplayName("2.4 商品不存在时返回提示")
    void productDetail_rejectsMissingProduct() throws Exception {
        assertThat(failMsg(getJson("/api/buyer/product/999"))).isEqualTo("商品不存在");
    }

    @Test
    @DisplayName("2.4 商品 ID 格式错误时返回参数格式提示")
    void productDetail_rejectsInvalidIdFormat() throws Exception {
        assertThat(failMsg(getJson("/api/buyer/product/abc"))).isEqualTo("参数格式不正确：id");
    }

    @Test
    @DisplayName("2.30 商品评价列表返回聚合评分与评价内容")
    void productReviews_returnsAggregatedRating() throws Exception {
        JsonNode data = okData(getJson("/api/buyer/product/5/reviews"));

        assertThat(data.path("productId").asInt()).isEqualTo(5);
        assertThat(data.path("averageRating").asDouble()).isEqualTo(5.0);
        assertThat(data.path("reviewCount").asInt()).isEqualTo(1);
        assertThat(data.path("total").asInt()).isEqualTo(1);
        assertThat(data.path("list").get(0).path("content").asText()).contains("骑行顺畅");
        assertThat(data.path("list").get(0).path("buyerMaskedName").asText()).isEqualTo("b**");
    }

    @Test
    @DisplayName("2.30 已下架商品不可查看评价")
    void productReviews_rejectsOfflineProduct() throws Exception {
        assertThat(failMsg(getJson("/api/buyer/product/4/reviews"))).isEqualTo("商品已下架");
    }

    @Test
    @DisplayName("2.18 商品分类树返回两级结构")
    void categoryTree_returnsTwoLevelTree() throws Exception {
        JsonNode data = okData(getJson("/api/buyer/category/tree"));

        assertThat(data).hasSize(3);
        assertThat(data.get(0).path("categoryName").asText()).isEqualTo("手机数码");
        assertThat(data.get(0).path("children")).isNotEmpty();
        assertThat(data.get(0).path("children").get(0).path("categoryName").asText()).isEqualTo("手机");
    }
}
