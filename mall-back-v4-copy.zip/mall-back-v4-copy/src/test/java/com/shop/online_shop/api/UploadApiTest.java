package com.shop.online_shop.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.shop.online_shop.support.ApiTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;

/**
 * 图片上传接口测试（复用 3.3 /api/seller/product/image/upload）
 */
@DisplayName("图片上传-接口")
class UploadApiTest extends ApiTestSupport {

    private static final String URL = "/api/seller/product/image/upload";

    @Test
    @DisplayName("3.3 未登录上传图片被拒绝")
    void upload_requiresLogin() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "a.png", "image/png", new byte[]{1, 2, 3});

        assertThat(failMsg(mockMvc.perform(multipart(URL).file(file)))).isEqualTo("请先登录");
    }

    @Test
    @DisplayName("3.3 仅支持 jpg / png 格式")
    void upload_rejectsInvalidExtension() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "a.txt", "text/plain", new byte[]{1});

        assertThat(failMsg(mockMvc.perform(multipart(URL)
                .file(file)
                .header("Authorization", "Bearer " + loginBuyer()))))
                .isEqualTo("仅支持 jpg / png 格式");
    }

    @Test
    @DisplayName("3.3 空文件上传被拒绝")
    void upload_rejectsEmptyFile() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "a.png", "image/png", new byte[0]);

        assertThat(failMsg(mockMvc.perform(multipart(URL)
                .file(file)
                .header("Authorization", "Bearer " + loginBuyer()))))
                .isEqualTo("请选择图片");
    }

    @Test
    @DisplayName("3.3 上传成功返回可访问图片地址")
    void upload_success() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "b.png", "image/png", new byte[]{1, 2, 3});

        JsonNode data = okData(mockMvc.perform(multipart(URL)
                .file(file)
                .header("Authorization", "Bearer " + loginBuyer())));

        assertThat(data.asText()).startsWith("/uploads/").endsWith(".png");
    }
}
