package com.shop.online_shop.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.shop.online_shop.support.ApiTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.ResultActions;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * 卖家端接口测试（需求 3.1 – 3.32）
 */
@DisplayName("卖家端-接口")
class SellerApiTest extends ApiTestSupport {

    private JsonNode sellerProductList(String token, String query) throws Exception {
        return okData(authGet("/api/seller/product/list?page=1&size=10" + query, token));
    }

    private int applyAfterSalesAsBuyer(int itemId) throws Exception {
        okData(authPost("/api/buyer/order/items/" + itemId + "/after-sales", loginBuyer(),
                Map.of("title", "商品问题", "description", "申请售后")));
        JsonNode list = okData(authGet("/api/seller/after-sales/list?page=1&size=10", loginSeller()));
        return list.path("list").get(0).path("id").asInt();
    }

    // ===================== 账号 3.1 – 3.2 =====================

    @Test
    @DisplayName("3.1 卖家登录成功返回令牌")
    void sellerLogin_returnsToken() throws Exception {
        assertThat(loginSeller()).hasSize(48);
    }

    @Test
    @DisplayName("3.1 卖家密码错误登录失败")
    void sellerLogin_rejectsWrongPassword() throws Exception {
        assertThat(failMsg(postJson("/api/seller/login", credentials(SELLER_USERNAME, "bad-password"))))
                .isEqualTo("用户名或密码错误");
    }

    @Test
    @DisplayName("3.1 未登录访问卖家接口返回 401")
    void sellerApi_requiresLogin() throws Exception {
        ResultActions actions = getJson("/api/seller/product/list")
                .andExpect(status().isUnauthorized());
        assertThat(body(actions).path("code").asInt()).isEqualTo(401);
    }

    @Test
    @DisplayName("3.2 修改密码后可用新密码登录")
    void modifyPassword_success() throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("oldPassword", SELLER_PASSWORD);
        body.put("newPassword", "seller456");
        okData(authPost("/api/seller/password/modify", loginSeller(), body));

        String token = okData(postJson("/api/seller/login", credentials(SELLER_USERNAME, "seller456"))).asText();
        assertThat(token).hasSize(48);
    }

    @Test
    @DisplayName("3.2 原密码错误时修改密码失败")
    void modifyPassword_rejectsWrongOldPassword() throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("oldPassword", "wrong-old");
        body.put("newPassword", "seller456");
        assertThat(failMsg(authPost("/api/seller/password/modify", loginSeller(), body)))
                .isEqualTo("原密码不正确");
    }

    @Test
    @DisplayName("3.2 新密码少于 8 位时修改失败")
    void modifyPassword_rejectsShortNewPassword() throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("oldPassword", SELLER_PASSWORD);
        body.put("newPassword", "short");
        assertThat(failMsg(authPost("/api/seller/password/modify", loginSeller(), body)))
                .isEqualTo("新密码不少于8位");
    }

    // ===================== 商品 3.4 – 3.11 / 3.24 =====================

    @Test
    @DisplayName("3.4 发布商品后在商品列表可见")
    void publishProduct_success() throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("name", "测试机械键盘");
        body.put("price", 399.00);
        body.put("stock", 5);
        body.put("categoryId", 5);
        body.put("description", "<p>手感不错</p>");

        okData(authPost("/api/seller/product/publish", loginSeller(), body));

        JsonNode list = sellerProductList(loginSeller(), "&keyword=测试机械键盘");
        assertThat(list.path("total").asInt()).isEqualTo(1);
        assertThat(list.path("list").get(0).path("status").asText()).isEqualTo("ONLINE");
    }

    @Test
    @DisplayName("3.4 发布商品必须选择二级分类")
    void publishProduct_rejectsFirstLevelCategory() throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("name", "分类错误商品");
        body.put("price", 10.00);
        body.put("stock", 1);
        body.put("categoryId", 1);

        assertThat(failMsg(authPost("/api/seller/product/publish", loginSeller(), body)))
                .isEqualTo("请选择二级分类");
    }

    @Test
    @DisplayName("3.4 发布商品价格非法时校验失败")
    void publishProduct_rejectsInvalidPrice() throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("name", "零元购");
        body.put("price", 0);
        body.put("stock", 1);
        body.put("categoryId", 5);

        assertThat(failMsg(authPost("/api/seller/product/publish", loginSeller(), body)))
                .isEqualTo("价格必须大于0");
    }

    @Test
    @DisplayName("3.5 商品列表按状态筛选")
    void productList_filtersByStatus() throws Exception {
        JsonNode list = sellerProductList(loginSeller(), "&status=OFFLINE");

        assertThat(list.path("total").asInt()).isEqualTo(1);
        assertThat(list.path("list").get(0).path("name").asText()).isEqualTo("iPad Air 5");
    }

    @Test
    @DisplayName("3.6 商品详情返回库存三层口径")
    void productDetail_returnsStockBreakdown() throws Exception {
        JsonNode data = okData(authGet("/api/seller/product/6", loginSeller()));

        assertThat(data.path("stock").asInt()).isEqualTo(20);
        assertThat(data.path("reservedQuantity").asInt()).isEqualTo(1);
        assertThat(data.path("availableQuantity").asInt()).isEqualTo(19);
        assertThat(data.path("shippedQuantity").asInt()).isEqualTo(1);
    }

    @Test
    @DisplayName("3.7 历史商品仅返回已下架商品")
    void productHistory_returnsOfflineProducts() throws Exception {
        JsonNode data = okData(authGet("/api/seller/product/history", loginSeller()));

        assertThat(data).hasSize(1);
        assertThat(data.get(0).path("status").asText()).isEqualTo("OFFLINE");
    }

    @Test
    @DisplayName("3.8 修改库存成功")
    void updateStock_success() throws Exception {
        okData(authPostNoBody("/api/seller/product/stock/1?stock=8", loginSeller()));

        JsonNode data = okData(authGet("/api/seller/product/1", loginSeller()));
        assertThat(data.path("stock").asInt()).isEqualTo(8);
    }

    @Test
    @DisplayName("3.8 库存改为 0 自动下架")
    void updateStock_zeroAutoOffline() throws Exception {
        okData(authPostNoBody("/api/seller/product/stock/1?stock=0", loginSeller()));

        JsonNode data = okData(authGet("/api/seller/product/1", loginSeller()));
        assertThat(data.path("stock").asInt()).isZero();
        assertThat(data.path("status").asText()).isEqualTo("OFFLINE");
        assertThat(data.path("offReason").asText()).isEqualTo("STOCK_OUT");
    }

    @Test
    @DisplayName("3.8 库存为负数时校验失败")
    void updateStock_rejectsNegative() throws Exception {
        assertThat(failMsg(authPostNoBody("/api/seller/product/stock/1?stock=-1", loginSeller())))
                .isEqualTo("库存不能为负");
    }

    @Test
    @DisplayName("3.10–3.11 下架与重新上架商品")
    void offShelfAndOnShelf_flow() throws Exception {
        String token = loginSeller();

        okData(authPostNoBody("/api/seller/product/off/1", token));
        JsonNode offline = okData(authGet("/api/seller/product/1", token));
        assertThat(offline.path("status").asText()).isEqualTo("OFFLINE");
        assertThat(offline.path("offReason").asText()).isEqualTo("MANUAL");

        okData(authPostNoBody("/api/seller/product/on/1", token));
        JsonNode online = okData(authGet("/api/seller/product/1", token));
        assertThat(online.path("status").asText()).isEqualTo("ONLINE");
    }

    @Test
    @DisplayName("3.9 修改商品分类")
    void reCategory_success() throws Exception {
        okData(authPostNoBody("/api/seller/product/1/recategory?categoryId=8", loginSeller()));

        JsonNode data = okData(authGet("/api/seller/product/1", loginSeller()));
        assertThat(data.path("categoryId").asInt()).isEqualTo(8);
        assertThat(data.path("categoryName").asText()).isEqualTo("手机数码 / 耳机");
    }

    @Test
    @DisplayName("3.24 设置活动价后买家端展示活动价")
    void setSalePrice_thenBuyerSeesCurrentPrice() throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("salePrice", 4999.00);
        body.put("saleStartAt", "2026-01-01 00:00:00");
        body.put("saleEndAt", "2030-01-01 00:00:00");
        okData(authPost("/api/seller/product/1/sale", loginSeller(), body));

        JsonNode detail = okData(getJson("/api/buyer/product/1"));
        assertThat(detail.path("salePrice").asDouble()).isEqualTo(4999.0);
        assertThat(detail.path("currentPrice").asDouble()).isEqualTo(4999.0);
    }

    @Test
    @DisplayName("3.24 活动结束时间早于开始时间被拒绝")
    void setSalePrice_rejectsInvalidWindow() throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("salePrice", 4999.00);
        body.put("saleStartAt", "2026-12-01 00:00:00");
        body.put("saleEndAt", "2026-11-01 00:00:00");

        assertThat(failMsg(authPost("/api/seller/product/1/sale", loginSeller(), body)))
                .isEqualTo("活动结束时间必须晚于开始时间");
    }

    @Test
    @DisplayName("3.12 按商品维度查询订单（下单时间正序）")
    void productOrders_returnsOrdersOfProduct() throws Exception {
        JsonNode data = okData(authGet("/api/seller/product/5/orders?page=1&size=10", loginSeller()));

        assertThat(data.path("total").asInt()).isEqualTo(1);
        assertThat(data.path("list").get(0).path("orderNo").asText()).isEqualTo("20261101-0001");
        assertThat(data.path("list").get(0).path("reservedQuantity").asInt()).isZero();
    }

    // ===================== 订单 3.13 – 3.17 =====================

    @Test
    @DisplayName("3.13 非已支付订单不可确认")
    void confirmOrder_rejectsWrongStatus() throws Exception {
        int orderId = createOrder(PRODUCT_AIRPODS, 1).path("id").asInt();

        assertThat(failMsg(authPostNoBody("/api/seller/order/" + orderId + "/confirm", loginSeller())))
                .isEqualTo("当前状态不允许该操作");
    }

    @Test
    @DisplayName("3.13–3.17 确认、备货、发货状态机推进")
    void sellerOrderFlow_transitions() throws Exception {
        JsonNode order = createPaidOrder(PRODUCT_AIRPODS, 1);
        int orderId = order.path("id").asInt();
        String token = loginSeller();

        okData(authPostNoBody("/api/seller/order/" + orderId + "/confirm", token));
        okData(authPostNoBody("/api/seller/order/" + orderId + "/stock-done", token));
        okData(authPost("/api/seller/order/" + orderId + "/ship", token,
                Map.of("logisticsProviderId", 1, "waybillNo", "SF7777777777")));

        JsonNode history = findHistoryOrder(loginBuyer(), orderId);
        assertThat(history.path("status").asText()).isEqualTo("SHIPPING");
        assertThat(history.path("logisticsProvider").asText()).isEqualTo("顺丰速运");
        assertThat(history.path("waybillNo").asText()).isEqualTo("SF7777777777");
        assertThat(history.path("canConfirmReceipt").asBoolean()).isTrue();
    }

    @Test
    @DisplayName("3.17 已发货订单卖家可取消并退款")
    void sellerCancel_shippedOrder() throws Exception {
        JsonNode order = createPaidOrder(PRODUCT_AIRPODS, 1);
        int orderId = order.path("id").asInt();
        String token = loginSeller();
        okData(authPostNoBody("/api/seller/order/" + orderId + "/confirm", token));
        okData(authPostNoBody("/api/seller/order/" + orderId + "/stock-done", token));
        okData(authPost("/api/seller/order/" + orderId + "/ship", token,
                Map.of("logisticsProviderId", 2, "waybillNo", "JD6666666666")));

        okData(authPostNoBody("/api/seller/order/" + orderId + "/cancel", token));
        assertThat(findHistoryOrder(loginBuyer(), orderId).path("status").asText()).isEqualTo("CANCELLED");
    }

    @Test
    @DisplayName("3.15 物流服务商不存在时不可发货")
    void ship_rejectsUnknownProvider() throws Exception {
        JsonNode order = createPaidOrder(PRODUCT_AIRPODS, 1);
        int orderId = order.path("id").asInt();
        String token = loginSeller();
        okData(authPostNoBody("/api/seller/order/" + orderId + "/confirm", token));
        okData(authPostNoBody("/api/seller/order/" + orderId + "/stock-done", token));

        assertThat(failMsg(authPost("/api/seller/order/" + orderId + "/ship", token,
                Map.of("logisticsProviderId", 999, "waybillNo", "X1"))))
                .isEqualTo("物流服务商不存在");
    }

    // ===================== 分类 3.18 – 3.21 =====================

    @Test
    @DisplayName("3.18 分类树返回各分类商品数")
    void categoryTree_withProductCount() throws Exception {
        JsonNode data = okData(authGet("/api/seller/category/tree", loginSeller()));

        assertThat(data).hasSize(3);
        JsonNode phones = data.get(0).path("children").get(0);
        assertThat(phones.path("categoryName").asText()).isEqualTo("手机");
        assertThat(phones.path("productCount").asInt()).isEqualTo(3);
    }

    @Test
    @DisplayName("3.19–3.21 分类新增、重命名、删除闭环")
    void categoryCrudFlow() throws Exception {
        String token = loginSeller();
        JsonNode created = okData(authPost("/api/seller/category", token,
                Map.of("parentId", 0, "categoryName", "运动户外")));
        int id = created.path("id").asInt();

        okData(authPostNoBody("/api/seller/category/rename/" + id + "?categoryName=户外运动", token));
        JsonNode tree = okData(authGet("/api/seller/category/tree", token));
        assertThat(tree.toString()).contains("户外运动");

        okData(authDelete("/api/seller/category/" + id, token));
        assertThat(okData(authGet("/api/seller/category/tree", token)).toString()).doesNotContain("户外运动");
    }

    @Test
    @DisplayName("3.21 分类下有商品时不可删除")
    void categoryDelete_rejectsCategoryWithProducts() throws Exception {
        assertThat(failMsg(authDelete("/api/seller/category/8", loginSeller())))
                .isEqualTo("分类下有商品，不可删除");
    }

    @Test
    @DisplayName("3.21 存在子分类时不可删除父分类")
    void categoryDelete_rejectsParentWithChildren() throws Exception {
        assertThat(failMsg(authDelete("/api/seller/category/1", loginSeller())))
                .isEqualTo("存在子分类，不可删除");
    }

    // ===================== 客户 3.22 – 3.23 =====================

    @Test
    @DisplayName("3.22 客户列表返回买家账号")
    void customers_returnsBuyerList() throws Exception {
        JsonNode data = okData(authGet("/api/seller/customer/list?page=1&size=10", loginSeller()));

        assertThat(data.path("total").asInt()).isEqualTo(1);
        assertThat(data.path("list").get(0).path("username").asText()).isEqualTo(BUYER_USERNAME);
    }

    @Test
    @DisplayName("3.23 查看客户历史订单")
    void customerHistory_returnsOrders() throws Exception {
        JsonNode data = okData(authGet("/api/seller/customer/buyer01/history?page=1&size=10", loginSeller()));

        assertThat(data.path("total").asInt()).isEqualTo(3);
    }

    @Test
    @DisplayName("3.23 客户不存在时返回提示")
    void customerHistory_rejectsUnknownCustomer() throws Exception {
        assertThat(failMsg(authGet("/api/seller/customer/nobody/history", loginSeller())))
                .isEqualTo("顾客不存在");
    }

    // ===================== 物流服务商 3.25 – 3.27 =====================

    @Test
    @DisplayName("3.25–3.27 物流服务商新增、查询、删除")
    void logisticsProviderCrud() throws Exception {
        String token = loginSeller();
        assertThat(okData(authGet("/api/seller/logistics/providers", token))).hasSize(2);

        int id = okData(authPost("/api/seller/logistics/providers", token,
                Map.of("name", "中通快递"))).path("id").asInt();
        assertThat(okData(authGet("/api/seller/logistics/providers", token))).hasSize(3);

        okData(authDelete("/api/seller/logistics/providers/" + id, token));
        assertThat(okData(authGet("/api/seller/logistics/providers", token))).hasSize(2);
    }

    @Test
    @DisplayName("3.26 物流服务商名称为空时校验失败")
    void logisticsProvider_rejectsBlankName() throws Exception {
        assertThat(failMsg(authPost("/api/seller/logistics/providers", loginSeller(),
                Map.of("name", " "))))
                .isEqualTo("物流服务商名称不能为空");
    }

    // ===================== 售后处理 3.28 – 3.32 =====================

    @Test
    @DisplayName("3.28–3.30 售后单列表、协商、录入仅退款结果")
    void afterSalesProcess_refundOnly() throws Exception {
        int afterSalesId = applyAfterSalesAsBuyer(2);
        String token = loginSeller();

        JsonNode list = okData(authGet("/api/seller/after-sales/list?page=1&size=10", token));
        assertThat(list.path("total").asInt()).isEqualTo(1);
        assertThat(list.path("list").get(0).path("status").asText()).isEqualTo("APPLYING");

        okData(authPostNoBody("/api/seller/after-sales/" + afterSalesId + "/negotiating", token));
        JsonNode negotiating = okData(authGet("/api/seller/after-sales/list?page=1&size=10", token));
        assertThat(negotiating.path("list").get(0).path("status").asText()).isEqualTo("NEGOTIATING");

        JsonNode result = okData(authPost("/api/seller/after-sales/" + afterSalesId + "/result", token,
                Map.of("result", "REFUND_ONLY", "remark", "同意仅退款")));
        assertThat(result.path("status").asText()).isEqualTo("CLOSED");
        assertThat(result.path("result").asText()).isEqualTo("REFUND_ONLY");

        assertThat(findHistoryOrder(loginBuyer(), 2).path("status").asText()).isEqualTo("CANCELLED");
    }

    @Test
    @DisplayName("3.30 不支持的售后结果被拒绝")
    void afterSalesResult_rejectsInvalidCode() throws Exception {
        int afterSalesId = applyAfterSalesAsBuyer(2);

        assertThat(failMsg(authPost("/api/seller/after-sales/" + afterSalesId + "/result", loginSeller(),
                Map.of("result", "FREE_REPAIR"))))
                .isEqualTo("不支持的售后结果");
    }

    @Test
    @DisplayName("3.31 退货退款确认收到退回件后生成退款")
    void afterSales_returnReceived() throws Exception {
        int afterSalesId = applyAfterSalesAsBuyer(2);
        String token = loginSeller();
        okData(authPostNoBody("/api/seller/after-sales/" + afterSalesId + "/negotiating", token));
        okData(authPost("/api/seller/after-sales/" + afterSalesId + "/result", token,
                Map.of("result", "REFUND_AND_RETURN")));

        JsonNode data = okData(authPost("/api/seller/after-sales/" + afterSalesId + "/return-received", token,
                Map.of("returnWaybillNo", "RET123456")));
        assertThat(data.path("refundNo").asText()).startsWith("RF");
        assertThat(data.path("orderStatus").asText()).isEqualTo("CANCELLED");
    }

    @Test
    @DisplayName("3.32 换货寄出登记成功")
    void afterSales_exchangeShip() throws Exception {
        int afterSalesId = applyAfterSalesAsBuyer(2);
        String token = loginSeller();
        okData(authPostNoBody("/api/seller/after-sales/" + afterSalesId + "/negotiating", token));
        JsonNode result = okData(authPost("/api/seller/after-sales/" + afterSalesId + "/result", token,
                Map.of("result", "EXCHANGE")));
        assertThat(result.path("result").asText()).isEqualTo("EXCHANGE");

        okData(authPost("/api/seller/after-sales/" + afterSalesId + "/exchange-ship", token,
                Map.of("returnWaybillNo", "RET0001", "exchangeWaybillNo", "NEW0001")));

        JsonNode list = okData(authGet("/api/seller/after-sales/list?page=1&size=10", token));
        assertThat(list.path("list").get(0).path("returnWaybillNo").asText()).isEqualTo("RET0001");
        assertThat(list.path("list").get(0).path("exchangeWaybillNo").asText()).isEqualTo("NEW0001");
    }

    @Test
    @DisplayName("3.32 换货登记缺少运单号时校验失败")
    void afterSales_exchangeShipRequiresWaybills() throws Exception {
        int afterSalesId = applyAfterSalesAsBuyer(2);
        String token = loginSeller();
        okData(authPostNoBody("/api/seller/after-sales/" + afterSalesId + "/negotiating", token));
        okData(authPost("/api/seller/after-sales/" + afterSalesId + "/result", token,
                Map.of("result", "EXCHANGE")));

        assertThat(failMsg(authPost("/api/seller/after-sales/" + afterSalesId + "/exchange-ship", token,
                Map.of("returnWaybillNo", " ", "exchangeWaybillNo", "NEW0002"))))
                .isEqualTo("寄回旧件运单号不能为空");
    }
}
