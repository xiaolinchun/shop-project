package com.shop.online_shop.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.shop.online_shop.support.ApiTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.ResultActions;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * 买家端购物车与收藏接口测试（需求 2.7 – 2.14）
 */
@DisplayName("买家端-购物车与收藏接口")
class BuyerCartApiTest extends ApiTestSupport {

    private int addToCart(String token, int productId, Integer quantity) throws Exception {
        return okData(authPost("/api/buyer/cart", token,
                Map.of("productId", productId, "quantity", quantity))).asInt();
    }

    @Test
    @DisplayName("2.7 未登录访问购物车返回 401")
    void cart_requiresLogin() throws Exception {
        ResultActions actions = getJson("/api/buyer/cart")
                .andExpect(status().isUnauthorized());
        JsonNode root = body(actions);
        assertThat(root.path("code").asInt()).isEqualTo(401);
        assertThat(root.path("msg").asText()).isEqualTo("请先登录");
    }

    @Test
    @DisplayName("2.7 加入购物车后购物车列表返回商品信息")
    void addToCart_thenList() throws Exception {
        String token = loginBuyer();
        addToCart(token, PRODUCT_IPHONE, 2);

        List<JsonNode> items = cartItems(token);
        assertThat(items).hasSize(1);
        assertThat(items.get(0).path("productId").asInt()).isEqualTo(PRODUCT_IPHONE);
        assertThat(items.get(0).path("quantity").asInt()).isEqualTo(2);
        assertThat(items.get(0).path("unitPrice").asDouble()).isEqualTo(5999.0);
        assertThat(items.get(0).path("onSale").asBoolean()).isTrue();
    }

    @Test
    @DisplayName("2.7 同商品重复加购数量累加不新增条目")
    void addToCart_sameProductAccumulates() throws Exception {
        String token = loginBuyer();
        addToCart(token, PRODUCT_IPHONE, 1);
        addToCart(token, PRODUCT_IPHONE, 1);

        List<JsonNode> items = cartItems(token);
        assertThat(items).hasSize(1);
        assertThat(items.get(0).path("quantity").asInt()).isEqualTo(2);
    }

    @Test
    @DisplayName("2.7 已下架商品不可加入购物车")
    void addToCart_rejectsOfflineProduct() throws Exception {
        String token = loginBuyer();
        assertThat(failMsg(authPost("/api/buyer/cart", token,
                Map.of("productId", PRODUCT_IPAD_OFFLINE, "quantity", 1))))
                .isEqualTo("商品已下架");
    }

    @Test
    @DisplayName("2.7 数量超出 1~999 返回提示")
    void addToCart_rejectsInvalidQuantity() throws Exception {
        String token = loginBuyer();
        assertThat(failMsg(authPost("/api/buyer/cart", token,
                Map.of("productId", PRODUCT_IPHONE, "quantity", 1000))))
                .isEqualTo("数量必须在1~999之间");
    }

    @Test
    @DisplayName("2.7 商品 ID 缺失时参数校验失败")
    void addToCart_requiresProductId() throws Exception {
        String token = loginBuyer();
        assertThat(failMsg(authPost("/api/buyer/cart", token, Map.of("quantity", 1))))
                .isEqualTo("商品ID不能为空");
    }

    @Test
    @DisplayName("2.9 修改数量为 0 等同移除条目")
    void updateQuantity_zeroRemovesItem() throws Exception {
        String token = loginBuyer();
        int id = addToCart(token, PRODUCT_IPHONE, 3);

        okData(authPutNoBody("/api/buyer/cart/" + id + "/quantity?quantity=0", token));
        assertThat(cartItems(token)).isEmpty();
    }

    @Test
    @DisplayName("2.9 修改数量为非法值时提示")
    void updateQuantity_rejectsNegative() throws Exception {
        String token = loginBuyer();
        int id = addToCart(token, PRODUCT_IPHONE, 1);

        assertThat(failMsg(authPutNoBody("/api/buyer/cart/" + id + "/quantity?quantity=-1", token)))
                .isEqualTo("数量必须在0~999之间");
    }

    @Test
    @DisplayName("2.10 移除购物车条目")
    void removeCartItem_success() throws Exception {
        String token = loginBuyer();
        int id = addToCart(token, PRODUCT_IPHONE, 1);

        okData(authDelete("/api/buyer/cart/" + id, token));
        assertThat(cartItems(token)).isEmpty();
    }

    @Test
    @DisplayName("2.9 操作他人购物车条目返回无权访问")
    void updateQuantity_rejectsOtherBuyerItem() throws Exception {
        String otherToken = registerBuyer("cartbuyer02");
        int otherItemId = addToCart(otherToken, PRODUCT_IPHONE, 1);

        String token = loginBuyer();
        assertThat(failMsg(authPutNoBody("/api/buyer/cart/" + otherItemId + "/quantity?quantity=2", token)))
                .isEqualTo("无权访问");
    }

    @Test
    @DisplayName("2.11 购物车批量转收藏并从购物车移除")
    void cartToFavorite_movesItems() throws Exception {
        String token = loginBuyer();
        int first = addToCart(token, PRODUCT_IPHONE, 1);
        int second = addToCart(token, PRODUCT_MACBOOK, 1);

        JsonNode count = okData(authPost("/api/buyer/cart/to-favorite", token,
                Map.of("cartItemIds", List.of(first, second))));
        assertThat(count.asInt()).isEqualTo(2);
        assertThat(cartItems(token)).isEmpty();

        JsonNode favorites = okData(authGet("/api/buyer/favorite/list", token));
        assertThat(favorites).hasSize(2);
    }

    @Test
    @DisplayName("2.11 购物车转收藏未选择条目时校验失败")
    void cartToFavorite_requiresItems() throws Exception {
        String token = loginBuyer();
        assertThat(failMsg(authPost("/api/buyer/cart/to-favorite", token,
                Map.of("cartItemIds", List.of()))))
                .isEqualTo("请至少选择一条记录");
    }

    @Test
    @DisplayName("2.12–2.14 收藏、查看收藏、取消收藏")
    void favorite_addListRemove() throws Exception {
        String token = loginBuyer();

        okData(authPost("/api/buyer/favorite/" + PRODUCT_MACBOOK, token, null));
        JsonNode favorites = okData(authGet("/api/buyer/favorite/list", token));
        assertThat(favorites).hasSize(1);
        assertThat(favorites.get(0).path("productId").asInt()).isEqualTo(PRODUCT_MACBOOK);
        assertThat(favorites.get(0).path("onSale").asBoolean()).isTrue();

        okData(authDelete("/api/buyer/favorite/" + PRODUCT_MACBOOK, token));
        assertThat(okData(authGet("/api/buyer/favorite/list", token))).isEmpty();
    }

    @Test
    @DisplayName("2.12 重复收藏保持幂等")
    void addFavorite_isIdempotent() throws Exception {
        String token = loginBuyer();
        okData(authPost("/api/buyer/favorite/" + PRODUCT_MI14, token, null));
        okData(authPost("/api/buyer/favorite/" + PRODUCT_MI14, token, null));

        assertThat(okData(authGet("/api/buyer/favorite/list", token))).hasSize(1);
    }

    @Test
    @DisplayName("2.12 收藏不存在的商品返回提示")
    void addFavorite_rejectsMissingProduct() throws Exception {
        String token = loginBuyer();
        assertThat(failMsg(authPost("/api/buyer/favorite/999", token, null))).isEqualTo("商品不存在");
    }
}
