package com.shop.online_shop.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.shop.online_shop.support.ApiTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * 支付渠道回调接口测试（需求 4.1）
 */
@DisplayName("支付回调-接口")
class PaymentNotifyApiTest extends ApiTestSupport {

    @Test
    @DisplayName("4.1 支付成功回调将订单推进为已支付")
    void notify_success_marksOrderPaid() throws Exception {
        String token = loginBuyer();
        int orderId = createOrder(token, PRODUCT_AIRPODS, 1).path("id").asInt();
        String paymentNo = initiatePay(token, orderId, "ALIPAY").path("paymentNo").asText();

        JsonNode result = notifyPayment(paymentNo, "ALIPAY", "MOCK-TXN-0001", "SUCCESS");
        assertThat(result.path("status").asText()).isEqualTo("PAID");
        assertThat(result.path("refunded").asBoolean()).isFalse();

        JsonNode history = findHistoryOrder(token, orderId);
        assertThat(history.path("status").asText()).isEqualTo("PAID");
        assertThat(history.path("canPay").asBoolean()).isFalse();
        assertThat(history.path("paymentChannel").asText()).isEqualTo("ALIPAY");
    }

    @Test
    @DisplayName("4.1 支付失败回调不推进订单状态")
    void notify_fail_keepsPendingPayment() throws Exception {
        String token = loginBuyer();
        int orderId = createOrder(token, PRODUCT_AIRPODS, 1).path("id").asInt();
        String paymentNo = initiatePay(token, orderId, "WECHAT_PAY").path("paymentNo").asText();

        JsonNode result = notifyPayment(paymentNo, "WECHAT_PAY", "MOCK-TXN-0002", "FAIL");
        assertThat(result.path("status").asText()).isEqualTo("PENDING_PAYMENT");
        assertThat(result.path("refunded").asBoolean()).isFalse();
    }

    @Test
    @DisplayName("4.1 重复回调幂等，不重复预占")
    void notify_isIdempotent() throws Exception {
        String token = loginBuyer();
        int orderId = createOrder(token, PRODUCT_AIRPODS, 1).path("id").asInt();
        String paymentNo = initiatePay(token, orderId, "ALIPAY").path("paymentNo").asText();
        notifyPayment(paymentNo, "ALIPAY", "MOCK-TXN-0003", "SUCCESS");

        JsonNode second = notifyPayment(paymentNo, "ALIPAY", "MOCK-TXN-0003", "SUCCESS");
        assertThat(second.path("status").asText()).isEqualTo("PAID");
        assertThat(second.path("message").asText()).contains("忽略重复回调");
    }

    @Test
    @DisplayName("4.1 支付单不存在时返回提示")
    void notify_rejectsUnknownPaymentNo() throws Exception {
        assertThat(failMsg(postJson("/api/payment/notify",
                Map.of("paymentNo", "PAY-NOT-EXIST", "channel", "ALIPAY",
                        "channelTxnNo", "X1", "result", "SUCCESS"))))
                .isEqualTo("支付单不存在");
    }

    @Test
    @DisplayName("4.1 支付单号缺失时返回提示")
    void notify_requiresPaymentNo() throws Exception {
        assertThat(failMsg(postJson("/api/payment/notify",
                Map.of("channel", "ALIPAY", "result", "SUCCESS"))))
                .isEqualTo("支付单不存在");
    }

    @Test
    @DisplayName("4.1 回调渠道与支付单渠道不一致时拒绝")
    void notify_rejectsChannelMismatch() throws Exception {
        String token = loginBuyer();
        int orderId = createOrder(token, PRODUCT_AIRPODS, 1).path("id").asInt();
        String paymentNo = initiatePay(token, orderId, "ALIPAY").path("paymentNo").asText();

        assertThat(failMsg(postJson("/api/payment/notify",
                Map.of("paymentNo", paymentNo, "channel", "BANK_CARD",
                        "channelTxnNo", "X2", "result", "SUCCESS"))))
                .isEqualTo("不支持的支付渠道");
    }

    @Test
    @DisplayName("4.1 可卖量不足时自动原路退款并保持待支付")
    void notify_refundsWhenAvailableQuantityInsufficient() throws Exception {
        String token = loginBuyer();
        int orderId = createOrder(token, PRODUCT_MACBOOK, 3).path("id").asInt();
        String paymentNo = initiatePay(token, orderId, "CREDIT_CARD").path("paymentNo").asText();

        // 支付回调前卖家将库存改为 1，制造可卖量不足
        okData(authPostNoBody("/api/seller/product/stock/3?stock=1", loginSeller()));

        JsonNode result = notifyPayment(paymentNo, "CREDIT_CARD", "MOCK-TXN-0004", "SUCCESS");
        assertThat(result.path("refunded").asBoolean()).isTrue();
        assertThat(result.path("message").asText()).contains("可卖量不足");
        assertThat(result.path("status").asText()).isEqualTo("PENDING_PAYMENT");

        JsonNode history = findHistoryOrder(token, orderId);
        assertThat(history.path("status").asText()).isEqualTo("PENDING_PAYMENT");
        assertThat(history.path("canPay").asBoolean()).isTrue();
    }
}
