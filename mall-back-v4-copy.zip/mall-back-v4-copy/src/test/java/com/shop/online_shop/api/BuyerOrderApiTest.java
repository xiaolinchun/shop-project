package com.shop.online_shop.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.shop.online_shop.support.ApiTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * 买家端地址、订单、支付、物流、评价、售后接口测试
 * （需求 2.15 – 2.17、2.19 – 2.29）
 */
@DisplayName("买家端-地址与订单接口")
class BuyerOrderApiTest extends ApiTestSupport {

    // ===================== 辅助方法 =====================

    private int addAddress(String token, String name, boolean isDefault) throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("name", name);
        body.put("phone", "13600001111");
        body.put("province", "浙江");
        body.put("city", "杭州");
        body.put("district", "西湖区");
        body.put("detail", "文三路 100 号");
        body.put("isDefault", isDefault);
        return okData(authPost("/api/buyer/address", token, body)).path("id").asInt();
    }

    private int addCartItem(String token, int productId, int quantity) throws Exception {
        return okData(authPost("/api/buyer/cart", token,
                Map.of("productId", productId, "quantity", quantity))).asInt();
    }

    private void sellerConfirm(int orderId) throws Exception {
        okData(authPostNoBody("/api/seller/order/" + orderId + "/confirm", loginSeller()));
    }

    private void sellerStockDone(int orderId) throws Exception {
        okData(authPostNoBody("/api/seller/order/" + orderId + "/stock-done", loginSeller()));
    }

    private void sellerShip(int orderId, String waybillNo) throws Exception {
        okData(authPost("/api/seller/order/" + orderId + "/ship", loginSeller(),
                Map.of("logisticsProviderId", 1, "waybillNo", waybillNo)));
    }

    // ===================== 地址簿 2.21 – 2.25 =====================

    @Test
    @DisplayName("2.21 地址列表默认地址置顶")
    void addressList_returnsDefaultFirst() throws Exception {
        JsonNode data = okData(authGet("/api/buyer/address/list", loginBuyer()));

        assertThat(data).hasSize(2);
        assertThat(data.get(0).path("name").asText()).isEqualTo("张三");
        assertThat(data.get(0).path("isDefault").asBoolean()).isTrue();
    }

    @Test
    @DisplayName("2.22–2.25 地址新增、编辑、设默认、删除闭环")
    void addressCrudFlow() throws Exception {
        String token = loginBuyer();
        int id = addAddress(token, "王五", false);

        Map<String, Object> update = new HashMap<>();
        update.put("name", "王五五");
        update.put("phone", "13600002222");
        okData(authPut("/api/buyer/address/" + id, token, update));

        okData(authPostNoBody("/api/buyer/address/" + id + "/default", token));
        JsonNode list = okData(authGet("/api/buyer/address/list", token));
        assertThat(list).hasSize(3);
        assertThat(list.get(0).path("id").asInt()).isEqualTo(id);
        assertThat(list.get(0).path("name").asText()).isEqualTo("王五五");

        okData(authDelete("/api/buyer/address/" + id, token));
        assertThat(okData(authGet("/api/buyer/address/list", token))).hasSize(2);
    }

    @Test
    @DisplayName("2.22 地址必填项缺失时返回提示")
    void addressAdd_rejectsIncomplete() throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("name", "王五");
        body.put("phone", "13600001111");
        assertThat(failMsg(authPost("/api/buyer/address", loginBuyer(), body)))
                .isEqualTo("地址信息不完整");
    }

    @Test
    @DisplayName("2.23 编辑他人地址返回无权访问")
    void addressUpdate_rejectsOtherBuyer() throws Exception {
        String otherToken = registerBuyer("addressbuyer02");
        Map<String, Object> body = new HashMap<>();
        body.put("name", "黑客");
        assertThat(failMsg(authPut("/api/buyer/address/1", otherToken, body)))
                .isEqualTo("无权访问");
    }

    // ===================== 订单 2.15 – 2.17 =====================

    @Test
    @DisplayName("2.15 商品详情页直接下单进入待支付并生成地址快照")
    void createOrder_directByProduct() throws Exception {
        JsonNode order = createOrder(PRODUCT_AIRPODS, 1);

        assertThat(order.path("status").asText()).isEqualTo("PENDING_PAYMENT");
        assertThat(order.path("totalAmount").asDouble()).isEqualTo(1599.0);
        assertThat(order.path("orderNo").asText()).startsWith("20");
        assertThat(order.path("items")).hasSize(1);
        assertThat(order.path("items").get(0).path("productId").asInt()).isEqualTo(PRODUCT_AIRPODS);
        assertThat(order.path("addressSnapshot").path("name").asText()).isEqualTo("张三");
        assertThat(order.path("buyerUsername").asText()).isEqualTo(BUYER_USERNAME);
    }

    @Test
    @DisplayName("2.15 购物车勾选下单成功后清空已下单项")
    void createOrder_fromCart() throws Exception {
        String token = loginBuyer();
        int first = addCartItem(token, PRODUCT_IPHONE, 2);
        int second = addCartItem(token, PRODUCT_MI14, 1);

        JsonNode order = okData(authPost("/api/buyer/order", token,
                Map.of("cartItemIds", List.of(first, second))));

        assertThat(order.path("totalAmount").asDouble()).isEqualTo(18497.0);
        assertThat(order.path("items")).hasSize(2);
        assertThat(cartItems(token)).isEmpty();
    }

    @Test
    @DisplayName("2.15 可卖量不足时下单失败")
    void createOrder_rejectsInsufficientAvailable() throws Exception {
        String msg = failMsg(authPost("/api/buyer/order", loginBuyer(),
                Map.of("productId", PRODUCT_MACBOOK, "quantity", 4)));
        assertThat(msg).contains("可卖量不足");
    }

    @Test
    @DisplayName("2.15 已下架商品不可下单")
    void createOrder_rejectsOfflineProduct() throws Exception {
        assertThat(failMsg(authPost("/api/buyer/order", loginBuyer(),
                Map.of("productId", PRODUCT_IPAD_OFFLINE, "quantity", 1))))
                .isEqualTo("商品已下架");
    }

    @Test
    @DisplayName("2.15 未选择任何商品时下单失败")
    void createOrder_rejectsEmptyLines() throws Exception {
        assertThat(failMsg(authPost("/api/buyer/order", loginBuyer(), Map.of())))
                .isEqualTo("购物车为空或未勾选商品");
    }

    @Test
    @DisplayName("2.16 订单历史返回种子订单与可用操作标记")
    void orderHistory_returnsOrdersWithFlags() throws Exception {
        JsonNode data = okData(authGet("/api/buyer/order/history?page=1", loginBuyer()));

        assertThat(data.path("total").asInt()).isEqualTo(3);
        assertThat(data.path("size").asInt()).isEqualTo(20);

        JsonNode shippingOrder = findInPage(data, 2);
        assertThat(shippingOrder.path("status").asText()).isEqualTo("SHIPPING");
        assertThat(shippingOrder.path("canConfirmReceipt").asBoolean()).isTrue();
        assertThat(shippingOrder.path("canAfterSales").asBoolean()).isTrue();
        assertThat(shippingOrder.path("shippingQuery").asBoolean()).isTrue();

        JsonNode completedOrder = findInPage(data, 3);
        assertThat(completedOrder.path("status").asText()).isEqualTo("COMPLETED");
        assertThat(completedOrder.path("canReview").asBoolean()).isTrue();
    }

    private JsonNode findInPage(JsonNode page, int orderId) {
        for (JsonNode order : page.path("list")) {
            if (order.path("id").asInt() == orderId) {
                return order;
            }
        }
        throw new AssertionError("订单历史中未找到订单 id=" + orderId);
    }

    @Test
    @DisplayName("2.17 待支付订单可取消")
    void cancelOrder_pendingPayment() throws Exception {
        String token = loginBuyer();
        int orderId = createOrder(token, PRODUCT_AIRPODS, 1).path("id").asInt();

        okData(authPostNoBody("/api/buyer/order/" + orderId + "/cancel", token));
        assertThat(findHistoryOrder(token, orderId).path("status").asText()).isEqualTo("CANCELLED");
    }

    @Test
    @DisplayName("2.17 重复取消订单返回提示")
    void cancelOrder_twiceRejected() throws Exception {
        String token = loginBuyer();
        int orderId = createOrder(token, PRODUCT_AIRPODS, 1).path("id").asInt();
        okData(authPostNoBody("/api/buyer/order/" + orderId + "/cancel", token));

        assertThat(failMsg(authPostNoBody("/api/buyer/order/" + orderId + "/cancel", token)))
                .isEqualTo("退款处理中，请勿重复取消");
    }

    @Test
    @DisplayName("2.17 取消他人订单返回无权访问")
    void cancelOrder_rejectsOtherBuyer() throws Exception {
        String otherToken = registerBuyer("orderbuyer02");
        assertThat(failMsg(authPostNoBody("/api/buyer/order/1/cancel", otherToken)))
                .isEqualTo("无权访问");
    }

    @Test
    @DisplayName("2.17 已支付订单取消触发原路退款并进入已取消")
    void cancelOrder_paidOrderRefunds() throws Exception {
        JsonNode order = createPaidOrder(PRODUCT_AIRPODS, 1);
        int orderId = order.path("id").asInt();

        okData(authPostNoBody("/api/buyer/order/" + orderId + "/cancel", loginBuyer()));
        assertThat(findHistoryOrder(loginBuyer(), orderId).path("status").asText()).isEqualTo("CANCELLED");
    }

    // ===================== 支付 2.19 =====================

    @Test
    @DisplayName("2.19 发起支付生成处理中的支付单")
    void pay_initiateSuccess() throws Exception {
        String token = loginBuyer();
        int orderId = createOrder(token, PRODUCT_AIRPODS, 1).path("id").asInt();

        JsonNode payment = initiatePay(token, orderId, "ALIPAY");
        assertThat(payment.path("paymentNo").asText()).startsWith("PAY");
        assertThat(payment.path("status").asText()).isEqualTo("PROCESSING");
        assertThat(payment.path("amount").asDouble()).isEqualTo(1599.0);
        assertThat(payment.path("channel").asText()).isEqualTo("ALIPAY");
    }

    @Test
    @DisplayName("2.19 不支持的支付渠道被拒绝")
    void pay_rejectsUnsupportedChannel() throws Exception {
        String token = loginBuyer();
        int orderId = createOrder(token, PRODUCT_AIRPODS, 1).path("id").asInt();

        assertThat(failMsg(authPost("/api/buyer/order/" + orderId + "/pay", token,
                Map.of("channel", "BITCOIN"))))
                .isEqualTo("不支持的支付渠道");
    }

    @Test
    @DisplayName("2.19 同一订单不可重复发起支付")
    void pay_rejectsDuplicateActivePayment() throws Exception {
        String token = loginBuyer();
        int orderId = createOrder(token, PRODUCT_AIRPODS, 1).path("id").asInt();
        initiatePay(token, orderId, "ALIPAY");

        assertThat(failMsg(authPost("/api/buyer/order/" + orderId + "/pay", token,
                Map.of("channel", "WECHAT_PAY"))))
                .isEqualTo("该订单已有进行中的支付");
    }

    @Test
    @DisplayName("2.19 支付他人订单返回无权访问")
    void pay_rejectsOtherBuyerOrder() throws Exception {
        String otherToken = registerBuyer("paybuyer02");
        assertThat(failMsg(authPost("/api/buyer/order/1/pay", otherToken,
                Map.of("channel", "ALIPAY"))))
                .isEqualTo("无权访问");
    }

    // ===================== 物流 2.26 / 确认收货 2.20 =====================

    @Test
    @DisplayName("2.26 查询已发货订单物流跟踪")
    void shipping_returnsTracking() throws Exception {
        JsonNode data = okData(authGet("/api/buyer/order/2/shipping", loginBuyer()));

        assertThat(data.path("orderNo").asText()).isEqualTo("20261102-0001");
        assertThat(data.path("logisticsProvider").asText()).isEqualTo("顺丰速运");
        assertThat(data.path("waybillNo").asText()).isEqualTo("SF1000000002");
        assertThat(data.path("tracking")).hasSize(2);
        assertThat(data.path("tracking").get(0).path("status").asText()).isEqualTo("IN_TRANSIT");
    }

    @Test
    @DisplayName("2.26 未发货订单查询物流返回提示")
    void shipping_rejectsNotShippedOrder() throws Exception {
        String token = loginBuyer();
        int orderId = createOrder(token, PRODUCT_AIRPODS, 1).path("id").asInt();

        assertThat(failMsg(authGet("/api/buyer/order/" + orderId + "/shipping", token)))
                .isEqualTo("订单尚未发货");
    }

    @Test
    @DisplayName("2.20 非发货中订单不可确认收货")
    void confirmReceipt_rejectsNonShippingOrder() throws Exception {
        JsonNode order = createPaidOrder(PRODUCT_AIRPODS, 1);
        int orderId = order.path("id").asInt();

        assertThat(failMsg(authPostNoBody("/api/buyer/order/" + orderId + "/confirm-receipt", loginBuyer())))
                .isEqualTo("当前状态不可确认收货");
    }

    @Test
    @DisplayName("2.20 确认收货完成交易并扣减库存，重复确认幂等")
    void confirmReceipt_fullFlow() throws Exception {
        JsonNode order = createPaidOrder(PRODUCT_AIRPODS, 1);
        // createPaidOrder 内部重新登录会刷新买家 token，此处需重新获取
        String token = loginBuyer();
        int orderId = order.path("id").asInt();

        sellerConfirm(orderId);
        sellerStockDone(orderId);
        sellerShip(orderId, "SF8888888888");

        JsonNode result = okData(authPostNoBody("/api/buyer/order/" + orderId + "/confirm-receipt", token));
        assertThat(result.path("status").asText()).isEqualTo("COMPLETED");
        assertThat(result.path("stockDeducted").asBoolean()).isTrue();

        JsonNode again = okData(authPostNoBody("/api/buyer/order/" + orderId + "/confirm-receipt", token));
        assertThat(again.path("status").asText()).isEqualTo("COMPLETED");
        assertThat(again.path("stockDeducted").asBoolean()).isTrue();

        assertThat(findHistoryOrder(token, orderId).path("status").asText()).isEqualTo("COMPLETED");
    }

    // ===================== 评价 2.29 / 2.30 =====================

    @Test
    @DisplayName("2.29 交易完成订单明细可提交评价并汇总到商品评价")
    void review_submitSuccess() throws Exception {
        String token = loginBuyer();
        JsonNode data = okData(authPost("/api/buyer/order/items/3/review", token,
                Map.of("rating", 5, "content", "影像旗舰，拍照很赞")));

        assertThat(data.path("reviewId").asInt()).isPositive();
        assertThat(data.path("productId").asInt()).isEqualTo(PRODUCT_MI14);

        JsonNode reviews = okData(getJson("/api/buyer/product/2/reviews"));
        assertThat(reviews.path("reviewCount").asInt()).isEqualTo(1);
        assertThat(reviews.path("averageRating").asDouble()).isEqualTo(5.0);
    }

    @Test
    @DisplayName("2.29 同一明细不可重复评价")
    void review_rejectsDuplicate() throws Exception {
        String token = loginBuyer();
        assertThat(failMsg(authPost("/api/buyer/order/items/1/review", token,
                Map.of("rating", 4, "content", "再来一次"))))
                .isEqualTo("该明细已评价");
    }

    @Test
    @DisplayName("2.29 评分超出 1~5 被拒绝")
    void review_rejectsInvalidRating() throws Exception {
        assertThat(failMsg(authPost("/api/buyer/order/items/3/review", loginBuyer(),
                Map.of("rating", 9, "content", "超纲评分"))))
                .isEqualTo("评分必须为1~5");
    }

    @Test
    @DisplayName("2.29 非交易完成订单不可评价")
    void review_rejectsNonCompletedOrder() throws Exception {
        assertThat(failMsg(authPost("/api/buyer/order/items/2/review", loginBuyer(),
                Map.of("rating", 5, "content", "还没收货"))))
                .isEqualTo("当前状态不可评价");
    }

    // ===================== 售后 2.27 – 2.28 =====================

    @Test
    @DisplayName("2.27 开始发货订单可发起售后申请")
    void afterSales_applyOnShippingOrder() throws Exception {
        String token = loginBuyer();
        JsonNode data = okData(authPost("/api/buyer/order/items/2/after-sales", token,
                Map.of("title", "耳机有杂音", "description", "左耳有电流声")));

        assertThat(data.path("afterSalesNo").asText()).startsWith("AS");
        assertThat(data.path("status").asText()).isEqualTo("APPLYING");
    }

    @Test
    @DisplayName("2.27 同一明细不可重复发起进行中的售后")
    void afterSales_rejectsDuplicateApply() throws Exception {
        String token = loginBuyer();
        Map<String, Object> body = Map.of("title", "耳机有杂音", "description", "左耳有电流声");
        okData(authPost("/api/buyer/order/items/2/after-sales", token, body));

        assertThat(failMsg(authPost("/api/buyer/order/items/2/after-sales", token, body)))
                .isEqualTo("该明细已有进行中的售后单");
    }

    @Test
    @DisplayName("2.27 待支付订单不可发起售后")
    void afterSales_rejectsPendingOrder() throws Exception {
        String token = loginBuyer();
        JsonNode order = createOrder(token, PRODUCT_AIRPODS, 1);
        int itemId = order.path("items").get(0).path("id").asInt();

        assertThat(failMsg(authPost("/api/buyer/order/items/" + itemId + "/after-sales", token,
                Map.of("title", "未支付申请", "description", "测试"))))
                .isEqualTo("当前订单状态不可发起售后");
    }

    @Test
    @DisplayName("2.28 我的售后单列表返回申请记录")
    void afterSales_listMine() throws Exception {
        String token = loginBuyer();
        okData(authPost("/api/buyer/order/items/2/after-sales", token,
                Map.of("title", "耳机有杂音", "description", "左耳有电流声")));

        JsonNode data = okData(authGet("/api/buyer/after-sales/list?page=1&size=10", token));
        assertThat(data.path("total").asInt()).isEqualTo(1);
        assertThat(data.path("list").get(0).path("status").asText()).isEqualTo("APPLYING");
        assertThat(data.path("list").get(0).path("orderNo").asText()).isEqualTo("20261102-0001");
    }

    @Test
    @DisplayName("2.27 对他人订单明细发起售后返回无权访问")
    void afterSales_rejectsOtherBuyerItem() throws Exception {
        String otherToken = registerBuyer("asbuyer02");
        assertThat(failMsg(authPost("/api/buyer/order/items/1/after-sales", otherToken,
                Map.of("title", "越权", "description", "测试"))))
                .isEqualTo("无权访问");
    }
}
