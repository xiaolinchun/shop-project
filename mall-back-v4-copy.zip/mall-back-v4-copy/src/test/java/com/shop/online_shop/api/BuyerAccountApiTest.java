package com.shop.online_shop.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.shop.online_shop.support.ApiTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * 买家账号接口测试（需求 2.5 – 2.6）
 */
@DisplayName("买家端-账号接口")
class BuyerAccountApiTest extends ApiTestSupport {

    @Test
    @DisplayName("2.5 注册成功返回登录令牌")
    void register_returnsToken() throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("username", "newbuyer");
        body.put("password", "12345678");
        body.put("phone", "13700001111");
        body.put("defaultTradeLocation", "图书馆正门");

        JsonNode data = okData(postJson("/api/buyer/register", body));
        assertThat(data.asText()).hasSize(48);
    }

    @Test
    @DisplayName("2.5 重复用户名注册被拒绝")
    void register_rejectsDuplicateUsername() throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("username", BUYER_USERNAME);
        body.put("password", "12345678");
        body.put("phone", "13700001111");

        assertThat(failMsg(postJson("/api/buyer/register", body))).isEqualTo("用户名已存在");
    }

    @Test
    @DisplayName("2.5 密码少于 8 位时校验失败")
    void register_rejectsShortPassword() throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("username", "shortpwd");
        body.put("password", "123");
        body.put("phone", "13700001111");

        assertThat(failMsg(postJson("/api/buyer/register", body))).isEqualTo("密码长度不能少于8位");
    }

    @Test
    @DisplayName("2.5 用户名为空时校验失败")
    void register_rejectsBlankUsername() throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("username", " ");
        body.put("password", "12345678");
        body.put("phone", "13700001111");

        assertThat(failMsg(postJson("/api/buyer/register", body))).isEqualTo("用户名不能为空");
    }

    @Test
    @DisplayName("2.6 登录成功返回令牌")
    void login_returnsToken() throws Exception {
        String token = loginBuyer();
        assertThat(token).hasSize(48);
    }

    @Test
    @DisplayName("2.6 密码错误登录失败")
    void login_rejectsWrongPassword() throws Exception {
        assertThat(failMsg(postJson("/api/buyer/login", credentials(BUYER_USERNAME, "wrong-password"))))
                .isEqualTo("用户名或密码错误");
    }

    @Test
    @DisplayName("2.6 登录参数缺失时校验失败")
    void login_rejectsMissingPassword() throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("username", BUYER_USERNAME);

        assertThat(failMsg(postJson("/api/buyer/login", body))).isEqualTo("密码不能为空");
    }
}
