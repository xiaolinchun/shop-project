package com.shop.online_shop.auth;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shop.online_shop.common.BusinessException;
import com.shop.online_shop.entity.BuyerAccount;
import com.shop.online_shop.entity.Seller;
import com.shop.online_shop.service.BuyerAccountService;
import com.shop.online_shop.service.SellerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class PermissionSecurityTest {

    private final BuyerAccountService buyerAccountService = mock(BuyerAccountService.class);
    private final SellerService sellerService = mock(SellerService.class);
    private final BuyerAuthInterceptor buyerAuthInterceptor = new BuyerAuthInterceptor();
    private final SellerAuthInterceptor sellerAuthInterceptor = new SellerAuthInterceptor();

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(buyerAuthInterceptor, "buyerAccountService", buyerAccountService);
        ReflectionTestUtils.setField(sellerAuthInterceptor, "sellerService", sellerService);
    }

    @Test
    void buyerIntentRequiresValidBearerToken() {
        MockHttpServletRequest request = new MockHttpServletRequest();

        BusinessException exception = assertThrows(BusinessException.class,
                () -> buyerAuthInterceptor.preHandle(request, new MockHttpServletResponse(), new Object()));

        assertEquals("请先登录", exception.getMessage());
    }

    @Test
    void buyerTokenSetsIdentityForIntentEndpoints() {
        BuyerAccount buyer = new BuyerAccount();
        buyer.setId(42);
        buyer.setUsername("buyer-a");
        when(buyerAccountService.getByToken("buyer-token")).thenReturn(buyer);
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer buyer-token");

        assertTrue(buyerAuthInterceptor.preHandle(request, new MockHttpServletResponse(), new Object()));
        assertEquals(42, request.getAttribute(BuyerAuthInterceptor.ATTR_BUYER_ID));
        assertEquals("buyer-a", request.getAttribute(BuyerAuthInterceptor.ATTR_BUYER_USERNAME));
    }

    @Test
    void invalidBuyerTokenIsRejected() {
        when(buyerAccountService.getByToken("invalid")).thenReturn(null);
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer invalid");

        assertThrows(BusinessException.class,
                () -> buyerAuthInterceptor.preHandle(request, new MockHttpServletResponse(), new Object()));
    }

    @Test
    void sellerManagementRequiresValidBearerToken() {
        MockHttpServletRequest request = new MockHttpServletRequest();

        BusinessException exception = assertThrows(BusinessException.class,
                () -> sellerAuthInterceptor.preHandle(request, new MockHttpServletResponse(), new Object()));

        assertEquals("请先登录", exception.getMessage());
    }

    @Test
    void sellerTokenSetsSellerIdentity() {
        Seller seller = new Seller();
        seller.setUsername("seller-a");
        when(sellerService.getByToken("seller-token")).thenReturn(seller);
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer seller-token");

        assertTrue(sellerAuthInterceptor.preHandle(request, new MockHttpServletResponse(), new Object()));
        assertEquals("seller-a", request.getAttribute(SellerAuthInterceptor.ATTR_SELLER_USERNAME));
    }

    @Test
    void accountAndSellerSecretsAreNotSerialized() throws Exception {
        BuyerAccount buyer = new BuyerAccount();
        buyer.setUsername("buyer-a");
        buyer.setPasswordHash("buyer-hash");
        buyer.setToken("buyer-token");
        Seller seller = new Seller();
        seller.setUsername("seller-a");
        seller.setPasswordHash("seller-hash");
        seller.setToken("seller-token");
        ObjectMapper objectMapper = new ObjectMapper();

        String buyerJson = objectMapper.writeValueAsString(buyer);
        String sellerJson = objectMapper.writeValueAsString(seller);

        assertTrue(buyerJson.contains("buyer-a"));
        assertFalse(buyerJson.contains("buyer-hash"));
        assertFalse(buyerJson.contains("buyer-token"));
        assertTrue(sellerJson.contains("seller-a"));
        assertFalse(sellerJson.contains("seller-hash"));
        assertFalse(sellerJson.contains("seller-token"));
    }
}
