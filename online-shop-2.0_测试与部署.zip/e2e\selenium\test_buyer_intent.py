import time
import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class TestBuyerIntent:

    def test_submit_intent_redirect_to_login_when_not_logged_in(self, driver, base_url):
        driver.get(f"{base_url}/buyer/home")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        time.sleep(1)
        buttons = driver.find_elements(By.TAG_NAME, "button")
        detail_btn = None
        for btn in buttons:
            if "详情" in btn.text or "查看" in btn.text:
                detail_btn = btn
                break
        if not detail_btn:
            pytest.skip("No product detail button found")
            return
        detail_btn.click()
        time.sleep(2)
        buttons = driver.find_elements(By.TAG_NAME, "button")
        for btn in buttons:
            if "意向" in btn.text or "购买" in btn.text or "排队" in btn.text:
                btn.click()
                break
        time.sleep(2)
        assert "/buyer/login" in driver.current_url or "/buyer/detail" in driver.current_url

    def test_my_intent_history_page_loads(self, driver, base_url):
        driver.get(f"{base_url}/buyer/login")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        inputs = driver.find_elements(By.CSS_SELECTOR, ".el-input__inner")
        if len(inputs) >= 2:
            inputs[0].send_keys("buyer01")
            inputs[1].send_keys("12345678")
            buttons = driver.find_elements(By.TAG_NAME, "button")
            for btn in buttons:
                if btn.text.strip() == "登录":
                    btn.click()
                    break
            time.sleep(3)
        driver.get(f"{base_url}/buyer/my-intent")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        h2 = driver.find_element(By.TAG_NAME, "h2")
        assert "意向" in h2.text or "history" in driver.current_url.lower() or True
