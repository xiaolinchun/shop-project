package com.shop.online_shop;

import com.shop.online_shop.entity.Intent;
import com.shop.online_shop.entity.Product;
import com.shop.online_shop.enums.IntentStatus;
import com.shop.online_shop.enums.ProductStatus;
import com.shop.online_shop.mapper.BuyerAccountMapper;
import com.shop.online_shop.mapper.IntentMapper;
import com.shop.online_shop.mapper.ProductMapper;
import com.shop.online_shop.service.impl.IntentServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class IntegrationTest {

    private final IntentMapper intentMapper = mock(IntentMapper.class);
    private final ProductMapper productMapper = mock(ProductMapper.class);
    private final BuyerAccountMapper buyerAccountMapper = mock(BuyerAccountMapper.class);
    private IntentServiceImpl intentService;

    @BeforeEach
    void setUp() {
        intentService = new IntentServiceImpl();
        ReflectionTestUtils.setField(intentService, "baseMapper", intentMapper);
        ReflectionTestUtils.setField(intentService, "productMapper", productMapper);
        ReflectionTestUtils.setField(intentService, "buyerAccountMapper", buyerAccountMapper);
    }

    @Test
    void buyerSubmissionCreatesBoundQueueEntryWithoutChangingStock() {
        Product product = product(8, 3, ProductStatus.ONLINE);
        when(productMapper.selectById(8)).thenReturn(product);
        when(intentMapper.insert(any(Intent.class))).thenAnswer(invocation -> {
            Intent intent = invocation.getArgument(0);
            intent.setId(101);
            return 1;
        });

        Integer intentId = intentService.submit(8, 42);

        assertEquals(101, intentId);
        assertEquals(3, product.getStock());
        ArgumentCaptor<Intent> intentCaptor = ArgumentCaptor.forClass(Intent.class);
        verify(intentMapper).insert(intentCaptor.capture());
        Intent savedIntent = intentCaptor.getValue();
        assertEquals(42, savedIntent.getBuyerAccountId());
        assertEquals(8, savedIntent.getProductId());
        assertEquals("Product 8", savedIntent.getProductName());
        assertEquals(IntentStatus.QUEUED, savedIntent.getStatus());
        assertEquals(null, savedIntent.getBuyerName());
        assertEquals(null, savedIntent.getPhone());
    }

    @Test
    void successfulTradeClosesIntentAndDecrementsStock() {
        Intent intent = new Intent();
        intent.setId(101);
        intent.setProductId(8);
        intent.setStatus(IntentStatus.TRADING);
        Product product = product(8, 2, ProductStatus.FROZEN);
        when(intentMapper.selectById(101)).thenReturn(intent);
        when(productMapper.selectById(8)).thenReturn(product);
        when(intentMapper.updateById(any(Intent.class))).thenReturn(1);
        when(productMapper.updateById(any(Product.class))).thenReturn(1);

        intentService.markTrade(101, "SUCCESS", "seller-a");

        assertEquals(IntentStatus.SUCCESS, intent.getStatus());
        assertEquals(1, product.getStock());
        assertEquals(ProductStatus.ONLINE, product.getStatus());
        verify(intentMapper).updateById(intent);
        verify(productMapper).updateById(product);
    }

    @Test
    void successfulLastItemTradeAutomaticallyTakesProductOffline() {
        Intent intent = new Intent();
        intent.setId(102);
        intent.setProductId(8);
        intent.setStatus(IntentStatus.TRADING);
        Product product = product(8, 1, ProductStatus.FROZEN);
        when(intentMapper.selectById(102)).thenReturn(intent);
        when(productMapper.selectById(8)).thenReturn(product);
        when(intentMapper.updateById(any(Intent.class))).thenReturn(1);
        when(productMapper.updateById(any(Product.class))).thenReturn(1);

        intentService.markTrade(102, "SUCCESS", "seller-a");

        assertEquals(0, product.getStock());
        assertEquals(ProductStatus.OFFLINE, product.getStatus());
        verify(productMapper).updateById(eq(product));
    }

    private Product product(Integer id, Integer stock, ProductStatus status) {
        Product product = new Product();
        product.setId(id);
        product.setName("Product " + id);
        product.setSellerId("seller-a");
        product.setStock(stock);
        product.setStatus(status);
        return product;
    }
}
