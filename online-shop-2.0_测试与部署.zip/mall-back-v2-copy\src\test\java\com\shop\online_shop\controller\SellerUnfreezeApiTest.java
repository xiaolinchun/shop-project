package com.shop.online_shop.controller;

import com.shop.online_shop.auth.SellerAuthInterceptor;
import com.shop.online_shop.common.BusinessException;
import com.shop.online_shop.common.GlobalExceptionHandler;
import com.shop.online_shop.service.BuyerAccountService;
import com.shop.online_shop.service.CategoryService;
import com.shop.online_shop.service.IntentService;
import com.shop.online_shop.service.ProductService;
import com.shop.online_shop.service.SellerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class SellerUnfreezeApiTest {

    private final ProductService productService = mock(ProductService.class);
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        SellerController controller = new SellerController();
        ReflectionTestUtils.setField(controller, "productService", productService);
        ReflectionTestUtils.setField(controller, "sellerService", mock(SellerService.class));
        ReflectionTestUtils.setField(controller, "intentService", mock(IntentService.class));
        ReflectionTestUtils.setField(controller, "categoryService", mock(CategoryService.class));
        ReflectionTestUtils.setField(controller, "buyerAccountService", mock(BuyerAccountService.class));

        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    @Test
    void unfreezeReturnsBusinessErrorWhenTradingIsInProgress() throws Exception {
        String message = "商品存在进行中的交易，请先标记交易结果";
        doThrow(new BusinessException(message)).when(productService).unfreeze(7, "seller-a");

        mockMvc.perform(post("/api/seller/product/unfreeze/{id}", 7)
                        .requestAttr(SellerAuthInterceptor.ATTR_SELLER_USERNAME, "seller-a"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(500))
                .andExpect(jsonPath("$.msg").value(message));

        verify(productService).unfreeze(7, "seller-a");
    }
}
