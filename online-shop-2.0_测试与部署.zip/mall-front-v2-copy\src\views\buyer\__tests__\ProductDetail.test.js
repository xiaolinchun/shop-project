import { describe, it, expect, beforeEach, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import ElementPlus from 'element-plus'
import ProductDetail from '@/views/buyer/ProductDetail.vue'

const mockUserStore = {
  buyerToken: 'fake-token',
  buyerInfo: { username: 'buyer1' }
}

vi.mock('@/api/buyer', () => ({
  getProductDetail: vi.fn().mockResolvedValue({
    code: 200,
    data: {
      id: 5, name: '无线鼠标 Pro', description: '<p>高精度无线鼠标</p>',
      price: 199.00, stock: 100, imageUrls: ['/img/mouse.jpg'],
      status: 'ONLINE', publishedAt: '2026-11-01'
    }
  }),
  submitIntent: vi.fn().mockResolvedValue({ code: 200 })
}))

vi.mock('@/stores/useUserStore', () => ({
  useUserStore: vi.fn(() => mockUserStore)
}))

const mockRouter = { push: vi.fn() }
const mockRoute = { params: { id: '5' } }
vi.mock('vue-router', () => ({
  useRouter: () => mockRouter,
  useRoute: () => mockRoute
}))

function createWrapper() {
  return mount(ProductDetail, {
    global: { plugins: [ElementPlus] }
  })
}

async function mountAndWait() {
  const wrapper = createWrapper()
  await new Promise(r => setTimeout(r, 50))
  return wrapper
}

describe('买家商品详情 ProductDetail.vue - FR-A03', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    mockUserStore.buyerToken = 'fake-token'
    mockUserStore.buyerInfo = { username: 'buyer1' }
  })

  it('onMounted 后 product 被赋值', async () => {
    const wrapper = await mountAndWait()
    expect(wrapper.vm.product).not.toBeNull()
    expect(wrapper.vm.product.name).toBe('无线鼠标 Pro')
  })

  describe('页面渲染', () => {
    it('显示商品名称', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('无线鼠标 Pro')
    })

    it('显示返回首页按钮', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('返回首页')
    })

    it('显示提交意向按钮', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('提交意向排队')
    })

    it('显示价格库存状态', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('价格')
      expect(wrapper.text()).toContain('库存')
      expect(wrapper.text()).toContain('状态')
    })

    it('ONLINE 商品提交按钮未禁用', async () => {
      const wrapper = await mountAndWait()
      const btn = wrapper.find('.el-button--primary')
      expect(btn.exists()).toBe(true)
    })
  })

  describe('FR-A03 提交意向成功', () => {
    it('handleSubmitIntent 调用 submitIntent 并传入 productId', async () => {
      const api = await import('@/api/buyer')
      const wrapper = await mountAndWait()
      await wrapper.vm.handleSubmitIntent()
      expect(api.submitIntent).toHaveBeenCalledWith(5)
    })
  })

  describe('FR-A03 未登录鉴权', () => {
    it('未登录买家提交意向时跳转 /buyer/login', async () => {
      mockUserStore.buyerToken = ''
      mockUserStore.buyerInfo = null
      const wrapper = await mountAndWait()
      await wrapper.vm.handleSubmitIntent()
      expect(mockRouter.push).toHaveBeenCalledWith('/buyer/login')
    })
  })
})