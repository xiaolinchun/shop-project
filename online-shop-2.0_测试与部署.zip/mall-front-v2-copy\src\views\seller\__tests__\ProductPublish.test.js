import { describe, it, expect, beforeEach, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import ElementPlus from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import ProductPublish from '@/views/seller/ProductPublish.vue'

vi.mock('@/api/seller', () => ({
  publishProduct: vi.fn().mockResolvedValue({ code: 200 }),
  uploadProductImage: vi.fn().mockResolvedValue({ code: 200, data: '/upload/img.jpg' }),
  getSellerCategoryTree: vi.fn().mockResolvedValue({
    code: 200,
    data: [
      { id: 1, categoryName: '电子产品', children: [
        { id: 101, categoryName: '电子配件' },
        { id: 102, categoryName: '手机' }
      ]}
    ]
  })
}))

const mockRouter = { push: vi.fn() }
vi.mock('vue-router', () => ({
  useRouter: () => mockRouter
}))

function createWrapper() {
  return mount(ProductPublish, {
    global: {
      plugins: [ElementPlus],
      components: { Plus }
    }
  })
}

describe('发布商品 ProductPublish.vue - FR-A07/FR-A09/FR-A10', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe('页面渲染', () => {
    it('显示"发布商品"标题', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('发布商品')
    })

    it('包含返回按钮', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('返回我的商品')
    })

    it('包含发布商品按钮', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('发布商品')
    })
  })

  describe('FR-A07 表单字段', () => {
    it('表单包含全部必要字段', () => {
      const wrapper = createWrapper()
      const text = wrapper.text()
      expect(text).toContain('商品名称')
      expect(text).toContain('价格')
      expect(text).toContain('库存')
      expect(text).toContain('所属二级分类')
      expect(text).toContain('富文本描述')
    })

    it('form 对象有所有字段', () => {
      const wrapper = createWrapper()
      const f = wrapper.vm.form
      expect(f).toHaveProperty('name')
      expect(f).toHaveProperty('price')
      expect(f).toHaveProperty('stock')
      expect(f).toHaveProperty('categoryId')
      expect(f).toHaveProperty('description')
      expect(f).toHaveProperty('imageUrls')
    })

    it('form.price 是数字类型', () => {
      const wrapper = createWrapper()
      expect(typeof wrapper.vm.form.price).toBe('number')
    })

    it('stock 初始为 1', () => {
      const wrapper = createWrapper()
      expect(wrapper.vm.form.stock).toBe(1)
    })

    it('支持最多 9 张图片上传', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('最多9张')
    })
  })

  describe('FR-A09/FR-A10 分类加载', () => {
    it('加载分类后 flatCategory 只有二级分类', async () => {
      const wrapper = createWrapper()
      await wrapper.vm.loadCat()
      expect(wrapper.vm.flatCategory.length).toBe(2)
      expect(wrapper.vm.flatCategory[0].categoryName).toBe('电子配件')
    })
  })

  describe('FR-A09 提交校验', () => {
    it('未填名称时提示', async () => {
      const wrapper = createWrapper()
      wrapper.vm.form.name = ''
      wrapper.vm.form.categoryId = 101
      await wrapper.vm.submitPublish()
      expect(mockRouter.push).not.toHaveBeenCalled()
    })

    it('未选分类时提示', async () => {
      const wrapper = createWrapper()
      wrapper.vm.form.name = '测试商品'
      wrapper.vm.form.categoryId = null
      await wrapper.vm.submitPublish()
      expect(mockRouter.push).not.toHaveBeenCalled()
    })

    it('正确填写后调用 publishProduct 并跳转', async () => {
      const api = await import('@/api/seller')
      const wrapper = createWrapper()
      wrapper.vm.form.name = '新商品'
      wrapper.vm.form.price = 99.9
      wrapper.vm.form.stock = 10
      wrapper.vm.form.categoryId = 101
      wrapper.vm.form.description = '<p>描述</p>'
      await wrapper.vm.submitPublish()
      expect(api.publishProduct).toHaveBeenCalled()
      expect(mockRouter.push).toHaveBeenCalledWith('/seller/product-list')
    })
  })
})