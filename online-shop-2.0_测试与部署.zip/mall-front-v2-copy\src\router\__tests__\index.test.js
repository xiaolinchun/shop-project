import { describe, it, expect, beforeEach, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { createRouter, createMemoryHistory } from 'vue-router'
import { useUserStore } from '@/stores/useUserStore'

vi.mock('@/stores/useUserStore', () => ({
  useUserStore: vi.fn()
}))

const routes = [
  { path: '/', name: 'HomeSelect', component: {} },
  { path: '/buyer/login', name: 'BuyerLogin', component: {} },
  { path: '/buyer/register', name: 'BuyerRegister', component: {} },
  { path: '/buyer/home', name: 'BuyerHome', component: {}, meta: { needBuyer: false } },
  { path: '/buyer/detail/:id', name: 'BuyerProductDetail', component: {}, meta: { needBuyer: false } },
  { path: '/buyer/my-intent', name: 'BuyerMyIntent', component: {}, meta: { needBuyer: true } },
  { path: '/seller/login', name: 'SellerLogin', component: {} },
  { path: '/seller/product-list', name: 'SellerProductList', component: {}, meta: { needSeller: true } },
  { path: '/seller/publish', name: 'SellerPublish', component: {}, meta: { needSeller: true } },
  { path: '/seller/category', name: 'SellerCategoryManage', component: {}, meta: { needSeller: true } },
  { path: '/seller/intent-queue/:productId', name: 'SellerIntentQueue', component: {}, meta: { needSeller: true } },
  { path: '/seller/customer', name: 'SellerCustomerList', component: {}, meta: { needSeller: true } },
  { path: '/seller/anonymous-intent', name: 'SellerAnonymousIntent', component: {}, meta: { needSeller: true } },
]

function createTestRouter(buyerToken = '', sellerToken = '') {
  useUserStore.mockReturnValue({
    buyerToken, sellerToken,
    buyerInfo: null, sellerInfo: null,
    buyerLogin: vi.fn(), sellerLogin: vi.fn(),
    buyerLogout: vi.fn(), sellerLogout: vi.fn(),
    setBuyerToken: vi.fn()
  })

  const router = createRouter({
    history: createMemoryHistory(),
    routes
  })

  router.beforeEach(async (to, from, next) => {
    if (!to.meta.needBuyer && !to.meta.needSeller) return next()
    const store = useUserStore()
    if (to.meta.needBuyer) {
      if (store.buyerToken) next()
      else next('/')
    } else if (to.meta.needSeller) {
      if (store.sellerToken) next()
      else next('/')
    } else {
      next()
    }
  })

  return router
}

describe('路由配置', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    vi.clearAllMocks()
  })

  it('首页 / 可以直接访问', async () => {
    const router = createTestRouter()
    await router.push('/')
    expect(router.currentRoute.value.path).toBe('/')
  })

  it('买家登录页 /buyer/login 可以直接访问', async () => {
    const router = createTestRouter()
    await router.push('/buyer/login')
    expect(router.currentRoute.value.path).toBe('/buyer/login')
  })

  it('买家注册页 /buyer/register 可以直接访问', async () => {
    const router = createTestRouter()
    await router.push('/buyer/register')
    expect(router.currentRoute.value.path).toBe('/buyer/register')
  })

  it('卖家登录页 /seller/login 可以直接访问', async () => {
    const router = createTestRouter()
    await router.push('/seller/login')
    expect(router.currentRoute.value.path).toBe('/seller/login')
  })

  it('买家首页 /buyer/home 无需登录可访问', async () => {
    const router = createTestRouter()
    await router.push('/buyer/home')
    expect(router.currentRoute.value.path).toBe('/buyer/home')
  })

  it('买家详情页 /buyer/detail/:id 无需登录可访问', async () => {
    const router = createTestRouter()
    await router.push('/buyer/detail/5')
    expect(router.currentRoute.value.path).toBe('/buyer/detail/5')
  })
})

describe('路由守卫 - 买家鉴权', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    vi.clearAllMocks()
  })

  it('未登录访问 /buyer/my-intent 被重定向到首页', async () => {
    const router = createTestRouter('', '')
    await router.push('/buyer/my-intent')
    await router.isReady()
    expect(router.currentRoute.value.path).toBe('/')
  })

  it('已登录买家访问 /buyer/my-intent 成功', async () => {
    const router = createTestRouter('buyer-token-123', '')
    await router.push('/buyer/my-intent')
    await router.isReady()
    expect(router.currentRoute.value.path).toBe('/buyer/my-intent')
  })
})

describe('路由守卫 - 卖家鉴权', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    vi.clearAllMocks()
  })

  it('未登录卖家访问 /seller/product-list 被重定向到首页', async () => {
    const router = createTestRouter('', '')
    await router.push('/seller/product-list')
    await router.isReady()
    expect(router.currentRoute.value.path).toBe('/')
  })

  it('已登录卖家访问 /seller/product-list 成功', async () => {
    const router = createTestRouter('', 'seller-token-abc')
    await router.push('/seller/product-list')
    await router.isReady()
    expect(router.currentRoute.value.path).toBe('/seller/product-list')
  })

  it('未登录卖家访问 /seller/publish 被重定向', async () => {
    const router = createTestRouter('', '')
    await router.push('/seller/publish')
    await router.isReady()
    expect(router.currentRoute.value.path).toBe('/')
  })

  it('未登录卖家访问 /seller/category 被重定向', async () => {
    const router = createTestRouter('', '')
    await router.push('/seller/category')
    await router.isReady()
    expect(router.currentRoute.value.path).toBe('/')
  })

  it('未登录卖家访问 /seller/customer 被重定向', async () => {
    const router = createTestRouter('', '')
    await router.push('/seller/customer')
    await router.isReady()
    expect(router.currentRoute.value.path).toBe('/')
  })

  it('未登录卖家访问 /seller/intent-queue/1 被重定向', async () => {
    const router = createTestRouter('', '')
    await router.push('/seller/intent-queue/1')
    await router.isReady()
    expect(router.currentRoute.value.path).toBe('/')
  })
})