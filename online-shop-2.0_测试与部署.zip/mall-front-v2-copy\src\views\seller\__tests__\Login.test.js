import { describe, it, expect, beforeEach, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import ElementPlus from 'element-plus'
import SellerLogin from '@/views/seller/Login.vue'

vi.mock('@/stores/useUserStore', () => ({
  useUserStore: vi.fn(() => ({
    sellerToken: '',
    sellerInfo: null,
    sellerLogin: vi.fn().mockResolvedValue({ code: 200 }),
  }))
}))

const mockRouter = { push: vi.fn() }
vi.mock('vue-router', () => ({
  useRouter: () => mockRouter
}))

function createWrapper() {
  return mount(SellerLogin, {
    global: { plugins: [ElementPlus] }
  })
}

describe('卖家登录 SellerLogin.vue', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    vi.clearAllMocks()
  })

  describe('页面渲染', () => {
    it('显示"卖家登录"标题', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('卖家登录')
    })

    it('包含账号和密码输入框', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('账号')
      expect(wrapper.text()).toContain('密码')
    })

    it('包含登录按钮', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('登录')
    })

    it('包含返回选择页按钮', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('返回选择页')
    })
  })

  describe('初始状态', () => {
    it('表单初始为空', () => {
      const wrapper = createWrapper()
      expect(wrapper.vm.form.username).toBe('')
      expect(wrapper.vm.form.password).toBe('')
    })

    it('loading 初始为 false', () => {
      const wrapper = createWrapper()
      expect(wrapper.vm.loading).toBe(false)
    })
  })

  describe('登录跳转', () => {
    it('登录成功后跳转到 /seller/product-list', async () => {
      const wrapper = createWrapper()
      wrapper.vm.form.username = 'seller1'
      wrapper.vm.form.password = 'sellerpass'
      await wrapper.vm.handleLogin()
      expect(mockRouter.push).toHaveBeenCalledWith('/seller/product-list')
    })
  })
})