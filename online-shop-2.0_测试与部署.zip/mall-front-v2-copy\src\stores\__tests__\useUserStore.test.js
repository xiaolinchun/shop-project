import { describe, it, expect, beforeEach, vi } from 'vitest'
import { setActivePinia, createPinia } from 'pinia'
import { useUserStore } from '@/stores/useUserStore'

vi.mock('@/api/request', () => ({
  default: {
    post: vi.fn(),
    get: vi.fn()
  }
}))

describe('useUserStore', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    localStorage.clear()
    vi.clearAllMocks()
  })

  describe('初始状态', () => {
    it('初始 buyerToken 为空字符串', () => {
      const store = useUserStore()
      expect(store.buyerToken).toBe('')
    })

    it('初始 sellerToken 为空字符串', () => {
      const store = useUserStore()
      expect(store.sellerToken).toBe('')
    })

    it('初始 buyerInfo 为 null', () => {
      const store = useUserStore()
      expect(store.buyerInfo).toBeNull()
    })

    it('初始 sellerInfo 为 null', () => {
      const store = useUserStore()
      expect(store.sellerInfo).toBeNull()
    })

    it('从 localStorage 恢复已保存的 buyerToken', () => {
      localStorage.setItem('buyerToken', 'stored-token')
      setActivePinia(createPinia())
      const store = useUserStore()
      expect(store.buyerToken).toBe('stored-token')
    })

    it('从 localStorage 恢复已保存的 sellerToken', () => {
      localStorage.setItem('sellerToken', 'stored-seller-token')
      setActivePinia(createPinia())
      const store = useUserStore()
      expect(store.sellerToken).toBe('stored-seller-token')
    })

    it('从 localStorage 恢复 buyerInfo 对象', () => {
      localStorage.setItem('buyerInfo', JSON.stringify({ username: 'testbuyer' }))
      setActivePinia(createPinia())
      const store = useUserStore()
      expect(store.buyerInfo).toEqual({ username: 'testbuyer' })
    })
  })

  describe('setBuyerToken', () => {
    it('设置 buyerToken 并同步到 localStorage', () => {
      const store = useUserStore()
      store.setBuyerToken('token-123', 'alice')
      expect(store.buyerToken).toBe('token-123')
      expect(store.buyerInfo).toEqual({ username: 'alice' })
      expect(localStorage.getItem('buyerToken')).toBe('token-123')
      expect(localStorage.getItem('buyerInfo')).toBe(JSON.stringify({ username: 'alice' }))
    })
  })

  describe('buyerLogin', () => {
    it('登录成功设置 token 和 userInfo', async () => {
      const api = await import('@/api/request')
      api.default.post.mockResolvedValueOnce({ code: 200, data: 'token-abc' })
      const store = useUserStore()
      const res = await store.buyerLogin({ username: 'alice', password: '12345678' })
      expect(res.code).toBe(200)
      expect(store.buyerToken).toBe('token-abc')
      expect(store.buyerInfo).toEqual({ username: 'alice' })
      expect(localStorage.getItem('buyerToken')).toBe('token-abc')
    })

    it('登录失败时不设置 token', async () => {
      const api = await import('@/api/request')
      api.default.post.mockResolvedValueOnce({ code: 401, data: null, msg: '账号或密码错误' })
      const store = useUserStore()
      const res = await store.buyerLogin({ username: 'alice', password: 'wrong' })
      expect(res.code).toBe(401)
      expect(store.buyerToken).toBe('')
      expect(store.buyerInfo).toBeNull()
    })
  })

  describe('sellerLogin', () => {
    it('卖家登录成功设置 token 和 userInfo', async () => {
      const api = await import('@/api/request')
      api.default.post.mockResolvedValueOnce({ code: 200, data: 'seller-token-xyz' })
      const store = useUserStore()
      const res = await store.sellerLogin({ username: 'seller1', password: 'sellerpass' })
      expect(res.code).toBe(200)
      expect(store.sellerToken).toBe('seller-token-xyz')
      expect(store.sellerInfo).toEqual({ username: 'seller1' })
      expect(localStorage.getItem('sellerToken')).toBe('seller-token-xyz')
    })

    it('卖家登录失败不设置 token', async () => {
      const api = await import('@/api/request')
      api.default.post.mockResolvedValueOnce({ code: 401, data: null, msg: '登录失败' })
      const store = useUserStore()
      await store.sellerLogin({ username: 'bad', password: 'wrong' })
      expect(store.sellerToken).toBe('')
      expect(store.sellerInfo).toBeNull()
    })
  })

  describe('buyerLogout', () => {
    it('清除 buyer 相关状态和 localStorage', () => {
      const store = useUserStore()
      store.setBuyerToken('old-token', 'alice')
      expect(store.buyerToken).toBe('old-token')
      store.buyerLogout()
      expect(store.buyerToken).toBe('')
      expect(store.buyerInfo).toBeNull()
      expect(localStorage.getItem('buyerToken')).toBeNull()
      expect(localStorage.getItem('buyerInfo')).toBeNull()
    })
  })

  describe('sellerLogout', () => {
    it('清除 seller 相关状态和 localStorage', () => {
      const store = useUserStore()
      store.sellerToken = 'old-seller-token'
      store.sellerInfo = { username: 'seller1' }
      localStorage.setItem('sellerToken', 'old-seller-token')
      store.sellerLogout()
      expect(store.sellerToken).toBe('')
      expect(store.sellerInfo).toBeNull()
      expect(localStorage.getItem('sellerToken')).toBeNull()
    })
  })
})