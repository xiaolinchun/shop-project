import { describe, it, expect, beforeEach, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import ElementPlus from 'element-plus'
import SellerProductList from '@/views/seller/SellerProductList.vue'

vi.mock('@/api/seller', () => ({
  getSellerProductList: vi.fn().mockResolvedValue({
    code: 200,
    data: {
      list: [
        { id: 1, name: '无线鼠标', categoryName: '电脑配件', price: 199.00, stock: 100, status: 'ONLINE' },
        { id: 2, name: '机械键盘', categoryName: '电脑配件', price: 399.00, stock: 50, status: 'FROZEN' },
        { id: 3, name: '蓝牙耳机', categoryName: '手机配件', price: 299.00, stock: 0, status: 'OFFLINE' }
      ],
      total: 3
    }
  }),
  freezeProduct: vi.fn().mockResolvedValue({ code: 200 }),
  unfreezeProduct: vi.fn().mockResolvedValue({ code: 200 }),
  offProduct: vi.fn().mockResolvedValue({ code: 200 }),
  onProduct: vi.fn().mockResolvedValue({ code: 200 }),
  updateStock: vi.fn().mockResolvedValue({ code: 200 }),
  getSellerProductDetail: vi.fn().mockResolvedValue({
    code: 200,
    data: { id: 1, name: '无线鼠标', imageUrls: ['/img/mouse.jpg'], price: 199, stock: 100, status: 'ONLINE', categoryName: '电脑配件', categoryId: 11, publishedAt: '2026-11-01', description: '好用鼠标' }
  })
}))

const mockRouter = { push: vi.fn() }
vi.mock('vue-router', () => ({
  useRouter: () => mockRouter
}))

function createWrapper() {
  return mount(SellerProductList, {
    global: { plugins: [ElementPlus] }
  })
}

async function mountAndWait() {
  const wrapper = createWrapper()
  await new Promise(r => setTimeout(r, 50))
  return wrapper
}

describe('卖家商品列表 SellerProductList.vue - FR-A07/FR-A09/FR-A12', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe('页面渲染', () => {
    it('显示发布新商品按钮', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('发布新商品')
    })

    it('显示状态筛选下拉占位文字', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('筛选状态')
    })

    it('显示商品数据', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('无线鼠标')
      expect(wrapper.text()).toContain('机械键盘')
      expect(wrapper.text()).toContain('蓝牙耳机')
    })

    it('表格包含全部列', async () => {
      const wrapper = await mountAndWait()
      const text = wrapper.text()
      expect(text).toContain('ID')
      expect(text).toContain('商品名')
      expect(text).toContain('种类')
      expect(text).toContain('价格')
      expect(text).toContain('库存')
      expect(text).toContain('状态')
    })
  })

  describe('FR-A07 状态筛选', () => {
    it('el-select 组件存在', async () => {
      const wrapper = await mountAndWait()
      const selects = wrapper.findAll('.el-select')
      expect(selects.length).toBeGreaterThanOrEqual(1)
    })

    it('query.status 有 3 种可选值 ONLINE/FROZEN/OFFLINE', () => {
      const wrapper = createWrapper()
      expect(wrapper.vm.query.status).toBeUndefined()
    })
  })

  describe('FR-A09 上下架操作', () => {
    it('ONLINE 商品显示"手动冻结"和"下架"按钮', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('手动冻结')
      expect(wrapper.text()).toContain('下架')
    })

    it('FROZEN 商品显示"解冻"按钮', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('解冻')
    })

    it('OFFLINE 商品显示"上架"按钮', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('上架')
    })
  })

  describe('FR-A12 库存管理', () => {
    it('所有行显示"修改库存"按钮', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('修改库存')
    })

    it('openStockDialog 设置 stockDialog 状态', async () => {
      const wrapper = await mountAndWait()
      wrapper.vm.openStockDialog({ id: 1, stock: 50 })
      expect(wrapper.vm.stockDialog.show).toBe(true)
      expect(wrapper.vm.stockDialog.id).toBe(1)
      expect(wrapper.vm.stockDialog.stock).toBe(50)
    })

    it('confirmStock 调用 updateStock 并关闭弹窗', async () => {
      const api = await import('@/api/seller')
      const wrapper = await mountAndWait()
      wrapper.vm.stockDialog.show = true
      wrapper.vm.stockDialog.id = 1
      wrapper.vm.stockDialog.stock = 30
      await wrapper.vm.confirmStock()
      expect(api.updateStock).toHaveBeenCalledWith(1, 30)
      expect(wrapper.vm.stockDialog.show).toBe(false)
    })
  })

  describe('初始值', () => {
    it('query 默认 page=1, size=10, status=undefined', () => {
      const wrapper = createWrapper()
      expect(wrapper.vm.query.page).toBe(1)
      expect(wrapper.vm.query.size).toBe(10)
      expect(wrapper.vm.query.status).toBeUndefined()
    })
  })
})