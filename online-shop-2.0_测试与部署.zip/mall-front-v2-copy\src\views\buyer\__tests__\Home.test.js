import { describe, it, expect, beforeEach, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import ElementPlus from 'element-plus'
import Home from '@/views/buyer/Home.vue'

vi.mock('@/api/buyer', () => ({
  getBuyerProductList: vi.fn().mockResolvedValue({
    code: 200,
    data: {
      list: [
        { id: 1, name: '无线鼠标', price: 199.00, categoryName: '电脑配件', status: 'ONLINE', publishedAt: '2026-11-01' },
        { id: 2, name: '机械键盘', price: 399.00, categoryName: '电脑配件', status: 'ONLINE', publishedAt: '2026-11-02' }
      ],
      total: 2
    }
  }),
  searchProduct: vi.fn().mockResolvedValue({
    code: 200,
    data: {
      list: [{ id: 1, name: '无线鼠标', price: 199.00, categoryName: '电脑配件', status: 'ONLINE', publishedAt: '2026-11-01' }],
      total: 1
    }
  }),
  getBuyerCategoryTree: vi.fn().mockResolvedValue({
    code: 200,
    data: [
      { id: 1, categoryName: '电子产品', children: [
        { id: 11, categoryName: '电脑配件', parentId: 1 },
        { id: 12, categoryName: '手机配件', parentId: 1 }
      ]},
      { id: 2, categoryName: '服装', children: [
        { id: 21, categoryName: '男装', parentId: 2 }
      ]}
    ]
  })
}))

const mockRouter = { push: vi.fn() }
vi.mock('vue-router', () => ({
  useRouter: () => mockRouter
}))

function createWrapper() {
  return mount(Home, {
    global: { plugins: [ElementPlus] }
  })
}

async function mountAndWait() {
  const wrapper = createWrapper()
  await new Promise(r => setTimeout(r, 50))
  return wrapper
}

describe('买家首页 Home.vue - FR-A05/FR-A06', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe('页面渲染', () => {
    it('显示"商品列表"标题', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('商品列表')
    })

    it('包含搜索相关按钮', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('搜索')
    })

    it('显示重置按钮', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('重置')
    })

    it('显示分页组件', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('Go to')
    })
  })

  describe('FR-A05 商品浏览', () => {
    it('调用 getBuyerProductList', async () => {
      const api = await import('@/api/buyer')
      await mountAndWait()
      expect(api.getBuyerProductList).toHaveBeenCalled()
    })

    it('page 默认 1, size 默认 10', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.vm.query.page).toBe(1)
      expect(wrapper.vm.query.size).toBe(10)
    })

    it('categoryId 默认 null', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.vm.query.categoryId).toBeNull()
    })
  })

  describe('FR-A05 分类筛选', () => {
    it('加载后 flatCategory 包含二级分类', async () => {
      const wrapper = await mountAndWait()
      await new Promise(r => setTimeout(r, 50))
      expect(wrapper.vm.flatCategory.length).toBe(3)
      expect(wrapper.vm.flatCategory[0].categoryName).toBe('电脑配件')
    })
  })

  describe('FR-A05 商品列表数据渲染', () => {
    it('表格显示商品数据', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('无线鼠标')
      expect(wrapper.text()).toContain('机械键盘')
      expect(wrapper.text()).toContain('电脑配件')
    })

    it('表格包含全部列', async () => {
      const wrapper = await mountAndWait()
      const text = wrapper.text()
      expect(text).toContain('ID')
      expect(text).toContain('商品名称')
      expect(text).toContain('价格')
      expect(text).toContain('分类名称')
      expect(text).toContain('状态')
      expect(text).toContain('查看详情')
    })
  })

  describe('FR-A06 搜索功能', () => {
    it('handleSearch 将 page 重置为 1', async () => {
      const wrapper = await mountAndWait()
      wrapper.vm.query.page = 3
      wrapper.vm.keyword = '鼠标'
      wrapper.vm.handleSearch()
      expect(wrapper.vm.query.page).toBe(1)
    })

    it('有关键字时调用 searchProduct', async () => {
      const api = await import('@/api/buyer')
      const wrapper = await mountAndWait()
      wrapper.vm.keyword = '无线'
      wrapper.vm.handleSearch()
      await new Promise(r => setTimeout(r, 20))
      expect(api.searchProduct).toHaveBeenCalled()
    })
  })

  describe('重置搜索', () => {
    it('resetSearch 重置关键字和筛选条件', async () => {
      const wrapper = await mountAndWait()
      wrapper.vm.keyword = '无线'
      wrapper.vm.query.categoryId = 11
      wrapper.vm.query.sort = 'TIME_ASC'
      wrapper.vm.query.page = 5
      wrapper.vm.resetSearch()
      expect(wrapper.vm.keyword).toBe('')
      expect(wrapper.vm.query.categoryId).toBeNull()
      expect(wrapper.vm.query.sort).toBe('TIME_DESC')
      expect(wrapper.vm.query.page).toBe(1)
    })
  })
})