[CmdletBinding()]
param(
    [ValidateSet('up', 'down', 'logs', 'ps')]
    [string]$Action = 'up'
)

$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw '未找到 Docker CLI。请先安装并启动 Docker Desktop。'
}

docker compose version | Out-Null
if ($LASTEXITCODE -ne 0) {
    throw '需要 Docker Compose v2。'
}

if (-not (Test-Path '.env')) {
    Copy-Item '.env.example' '.env'
    throw '已根据 .env.example 生成 .env，请先在 .env 中设置强密码，然后重新执行本脚本。'
}

switch ($Action) {
    'up'   { docker compose up -d --build }
    'down' { docker compose down }
    'logs' { docker compose logs -f --tail=100 }
    'ps'   { docker compose ps }
}

if ($LASTEXITCODE -ne 0) {
    throw "Docker Compose 操作 '$Action' 失败，退出码 $LASTEXITCODE。"
}
