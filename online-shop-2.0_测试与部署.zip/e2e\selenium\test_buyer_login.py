import time
import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class TestBuyerLogin:

    def test_login_page_loads(self, driver, base_url):
        driver.get(f"{base_url}/buyer/login")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        h2 = driver.find_element(By.TAG_NAME, "h2")
        assert "买家登录" in h2.text

    def test_login_form_has_two_inputs(self, driver, base_url):
        driver.get(f"{base_url}/buyer/login")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        inputs = driver.find_elements(By.CSS_SELECTOR, ".el-input__inner")
        assert len(inputs) >= 2

    def test_login_button_exists(self, driver, base_url):
        driver.get(f"{base_url}/buyer/login")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        buttons = driver.find_elements(By.TAG_NAME, "button")
        texts = [b.text.strip() for b in buttons]
        assert "登录" in texts

    def test_login_success_jumps_to_home(self, driver, base_url):
        driver.get(f"{base_url}/buyer/login")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )

        inputs = driver.find_elements(By.CSS_SELECTOR, ".el-input__inner")
        inputs[0].send_keys("buyer01")
        inputs[1].send_keys("12345678")

        buttons = driver.find_elements(By.TAG_NAME, "button")
        for btn in buttons:
            if btn.text.strip() == "登录":
                btn.click()
                break

        time.sleep(3)
        assert "/buyer/home" in driver.current_url

    def test_login_back_to_select_page(self, driver, base_url):
        driver.get(f"{base_url}/buyer/login")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        buttons = driver.find_elements(By.TAG_NAME, "button")
        for btn in buttons:
            if "返回" in btn.text:
                btn.click()
                break
        time.sleep(2)
        assert driver.current_url == base_url + "/" or driver.current_url.endswith("/")
