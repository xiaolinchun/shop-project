package com.shop.online_shop.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shop.online_shop.auth.BuyerAuthInterceptor;
import com.shop.online_shop.common.GlobalExceptionHandler;
import com.shop.online_shop.entity.Product;
import com.shop.online_shop.service.BuyerAccountService;
import com.shop.online_shop.service.CategoryService;
import com.shop.online_shop.service.IntentService;
import com.shop.online_shop.service.ProductService;
import com.shop.online_shop.vo.PageResult;
import com.shop.online_shop.vo.ProductListItemVO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class BuyerModuleTest {

    private final ProductService productService = mock(ProductService.class);
    private final CategoryService categoryService = mock(CategoryService.class);
    private final BuyerAccountService buyerAccountService = mock(BuyerAccountService.class);
    private final IntentService intentService = mock(IntentService.class);
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        BuyerController controller = new BuyerController();
        ReflectionTestUtils.setField(controller, "productService", productService);
        ReflectionTestUtils.setField(controller, "categoryService", categoryService);
        ReflectionTestUtils.setField(controller, "buyerAccountService", buyerAccountService);
        ReflectionTestUtils.setField(controller, "intentService", intentService);
        ReflectionTestUtils.setField(controller, "objectMapper", new ObjectMapper());

        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    @Test
    void productListPassesFilterSortAndPagination() throws Exception {
        when(productService.listProducts(12, "TIME_ASC", 2, 5))
                .thenReturn(new PageResult<>(List.<ProductListItemVO>of(), 0, 2, 5));

        mockMvc.perform(get("/api/buyer/product/list")
                        .param("categoryId", "12")
                        .param("sort", "TIME_ASC")
                        .param("page", "2")
                        .param("size", "5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data.page").value(2))
                .andExpect(jsonPath("$.data.size").value(5));

        verify(productService).listProducts(12, "TIME_ASC", 2, 5);
    }

    @Test
    void productSearchReturnsPagedResults() throws Exception {
        when(productService.searchProducts("phone", 1, 10))
                .thenReturn(new PageResult<>(List.<ProductListItemVO>of(), 0, 1, 10));

        mockMvc.perform(get("/api/buyer/product/search").param("keyword", "phone"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data.total").value(0));
    }

    @Test
    void currentAndDetailProductEndpointsReturnProducts() throws Exception {
        Product product = new Product();
        product.setId(7);
        product.setName("Test product");
        when(productService.getCurrentOnlineProduct()).thenReturn(product);
        when(productService.getProductDetail(7)).thenReturn(product);

        mockMvc.perform(get("/api/buyer/product/current"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.id").value(7));
        mockMvc.perform(get("/api/buyer/product/{id}", 7))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.name").value("Test product"));
    }

    @Test
    void registerAndLoginReturnTokens() throws Exception {
        when(buyerAccountService.register(any())).thenReturn("registered-token");
        when(buyerAccountService.login(any())).thenReturn("login-token");

        mockMvc.perform(post("/api/buyer/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"username":"buyer-a","password":"password123","phone":"13800000000","defaultTradeLocation":"North gate"}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").value("registered-token"));
        mockMvc.perform(post("/api/buyer/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"username":"buyer-a","password":"password123"}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").value("login-token"));
    }

    @Test
    void registerRejectsInvalidCredentials() throws Exception {
        mockMvc.perform(post("/api/buyer/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"username":"","password":"short","phone":""}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(500));
    }

    @Test
    void submitIntentUsesBuyerIdentityAndJsonProductId() throws Exception {
        when(intentService.submit(7, 42)).thenReturn(101);

        mockMvc.perform(post("/api/buyer/intent/submit")
                        .requestAttr(BuyerAuthInterceptor.ATTR_BUYER_ID, 42)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"productId":7}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data").value(101));

        verify(intentService).submit(7, 42);
    }

    @Test
    void intentHistoryUsesBuyerIdentityAndPagination() throws Exception {
        when(intentService.getHistory(eq(42), eq(3), eq(4)))
                .thenReturn(new PageResult<>(List.of(), 0, 3, 4));

        mockMvc.perform(get("/api/buyer/intent/history")
                        .requestAttr(BuyerAuthInterceptor.ATTR_BUYER_ID, 42)
                        .param("page", "3")
                        .param("size", "4"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.page").value(3))
                .andExpect(jsonPath("$.data.size").value(4));

        verify(intentService).getHistory(42, 3, 4);
    }

    @Test
    void categoryTreeIsAvailableWithoutAuthentication() throws Exception {
        mockMvc.perform(get("/api/buyer/category/tree"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data").isArray());
    }
}
