# E2E 测试报告（Selenium + JMeter）

| 项目 | 内容 |
|------|------|
| 被测系统 | 在线商城 v2.0（Spring Boot + Vue 3 + MySQL 8.0.44） |
| 测试类型 | 端到端功能测试（Selenium）、接口性能测试（JMeter） |
| 测试环境 | 本机 Docker Compose 部署，入口 `http://localhost:8088` |
| 测试日期 | 2026-11-04 |
| 测试结论 | **通过**：功能用例 30 通过 / 1 跳过 / 0 失败；性能场景 3 个，2692 次请求 0 失败 |

---

## 1. 测试范围与环境

### 1.1 系统部署形态

| 组件 | 版本 / 镜像 | 说明 |
|------|-------------|------|
| 前端 | Nginx（`nginx:stable-alpine`） | 静态资源托管，反向代理 `/api/`、`/uploads/` |
| 后端 | Spring Boot 2.0.0（JDK 21 运行） | 端口 8080，仅容器内网 |
| 数据库 | MySQL 8.0.44 | 数据卷持久化，初始化脚本导入 v2 表结构与演示数据 |
| 编排 | Docker Compose | db / backend / frontend 三容器 |

### 1.2 测试客户端环境

| 项目 | 版本 |
|------|------|
| 操作系统 | Windows 11（10.0.26200） |
| Python | 3.13.9 |
| pytest | 8.4.2 |
| pytest-html | 4.2.0 |
| 浏览器驱动 | Selenium + Chrome，`webdriver_manager` 自动匹配驱动 |
| JMeter | Apache JMeter 5.6.3 |
| Java（JMeter 运行） | 25.0.2 LTS |

### 1.3 测试数据

| 角色 | 账号 | 密码 |
|------|------|------|
| 买家 | buyer01 | 12345678 |
| 卖家 | seller01 | 123456 |

> 注册用例使用随机新账号，不污染既有数据。

---

## 2. 测试结果总览

| 测试类型 | 用例/场景数 | 请求/执行数 | 通过 | 跳过 | 失败 | 通过率 |
|----------|-------------|-------------|------|------|------|--------|
| Selenium 端到端功能 | 31 | 31 | 30 | 1 | 0 | 96.8%（跳过计入分母） |
| JMeter 接口性能 | 3 | 2692 | 2692 | 0 | 0 | 100% |

Selenium 总耗时 **2 分 48 秒**；JMeter 三个场景均在 12 秒内完成（登录场景含 5 秒渐进加压）。

---

## 3. Selenium 端到端功能测试

### 3.1 测试方式

- 框架：pytest + Selenium WebDriver（Chrome），每个用例独立浏览器会话；
- 入口地址通过环境变量 `E2E_BASE_URL` 指定，默认 `http://localhost:8088`；
- 断言基于真实页面元素、跳转地址与登录态，不直接调用接口；
- HTML 报告：[report.html](selenium/report.html)。

运行命令：

```powershell
cd c:\Users\32827\Desktop\online-shop-2.0\e2e\selenium
$env:E2E_BASE_URL = "http://localhost:8088"
pytest -v
```

### 3.2 分模块结果

| 模块 | 用例数 | 通过 | 跳过 | 失败 |
|------|--------|------|------|------|
| 首页与角色入口（test_home_select） | 5 | 5 | 0 | 0 |
| 买家注册（test_buyer_register） | 4 | 4 | 0 | 0 |
| 买家登录（test_buyer_login） | 5 | 5 | 0 | 0 |
| 买家商品浏览（test_buyer_browse） | 6 | 6 | 0 | 0 |
| 买家购买意向（test_buyer_intent） | 2 | 2 | 0 | 0 |
| 卖家商品管理（test_seller_product） | 5 | 5 | 0 | 0 |
| 卖家交易与分类（test_seller_trade） | 4 | 3 | 1 | 0 |
| **合计** | **31** | **30** | **1** | **0** |

### 3.3 用例明细

| 用例 | 验证点 | 结果 | 耗时 |
|------|--------|------|------|
| test_home_page_loads | 首页可正常加载 | 通过 | 4s |
| test_buyer_entry_button_exists | 买家入口按钮存在 | 通过 | 4s |
| test_seller_entry_button_exists | 卖家入口按钮存在 | 通过 | 3s |
| test_click_buyer_entry_navigates_to_login | 点击买家入口跳转买家登录页 | 通过 | 4s |
| test_click_seller_entry_navigates_to_login | 点击卖家入口跳转卖家登录页 | 通过 | 4s |
| test_register_page_loads | 注册页可加载 | 通过 | 3s |
| test_register_form_has_four_fields | 注册表单含 4 个字段 | 通过 | 4s |
| test_register_button_exists | 注册按钮存在 | 通过 | 4s |
| test_register_success_redirects_to_home | 注册成功后跳转首页 | 通过 | 7s |
| test_login_page_loads | 买家登录页可加载 | 通过 | 4s |
| test_login_form_has_two_inputs | 登录表单含用户名、密码输入框 | 通过 | 4s |
| test_login_button_exists | 登录按钮存在 | 通过 | 4s |
| test_login_success_jumps_to_home | 正确账号登录后跳转首页 | 通过 | 7s |
| test_login_back_to_select_page | 登录页可返回角色选择页 | 通过 | 6s |
| test_home_page_loads_product_list | 首页展示商品列表 | 通过 | 4s |
| test_home_page_has_search_and_reset | 搜索框与重置按钮可用 | 通过 | 4s |
| test_home_page_has_pagination | 商品分页组件存在 | 通过 | 4s |
| test_category_filter_exists | 分类筛选可用 | 通过 | 4s |
| test_click_product_detail | 点击商品进入详情页 | 通过 | 7s |
| test_search_product_by_keyword | 关键词搜索返回结果 | 通过 | 7s |
| test_submit_intent_redirect_to_login_when_not_logged_in | 未登录提交意向跳转登录 | 通过 | 9s |
| test_my_intent_history_page_loads | 登录后“我的意向”页可加载 | 通过 | 7s |
| test_seller_product_list_page_loads | 卖家商品列表页可加载（含登录态） | 通过 | 7s |
| test_seller_product_list_has_publish_button | 发布商品按钮存在 | 通过 | 7s |
| test_seller_product_list_has_filter | 商品筛选组件存在 | 通过 | 7s |
| test_seller_publish_product_page_loads | 发布商品页可加载 | 通过 | 7s |
| test_seller_publish_form_has_fields | 发布表单字段完整 | 通过 | 7s |
| test_intent_queue_page_loads | 意向队列页 | **跳过** | 7s |
| test_customer_list_page_loads | 客户列表页可加载 | 通过 | 7s |
| test_category_manage_page_loads | 分类管理页可加载 | 通过 | 7s |
| test_anonymous_intent_page_loads | 匿名意向页可加载 | 通过 | 7s |

### 3.4 跳过用例说明

`test_seller_trade.py::test_intent_queue_page_loads` 跳过原因为“当前没有可用的意向队列数据”（`No intent queue entries available`）。属于数据依赖型用例，功能代码未报错；补充意向数据后可复跑覆盖该场景。

---

## 4. JMeter 接口性能测试

### 4.1 测试方式

- 全部请求经 Nginx 入口 `http://localhost:8088`，同时覆盖静态页、`/api` 代理与后端鉴权；
- 每个请求配置双重断言：HTTP 200 + 响应体业务 `"code":200`；
- 单机 Docker Desktop 环境，未做分布式压测，结果用于验证功能容量与稳定性，不作为生产容量结论；
- 脚本位置：[e2e/jmeter](jmeter)，原始结果：[e2e/jmeter/results](jmeter/results)。

### 4.2 场景与指标

| 场景 | 脚本 | 并发 / 循环 | 请求组成 | 样本数 | 平均 | P90 | 最大 | 吞吐量 | 错误率 |
|------|------|-------------|----------|--------|------|-----|------|--------|--------|
| 冒烟测试 | `01-smoke.jmx` | 10 线程 / 1 次 | 首页、商品列表、搜索、详情 | 40 | 15.6ms | 23ms | 62ms | 22.2 req/s | 0% |
| 商品浏览 | `02-browse.jmx` | 100 线程 / 5 次 | 当前商品、列表、详情、搜索、分类树 | 2500 | 5.2ms | 8ms | 40ms | 225.2 req/s | 0% |
| 买家登录链路 | `03-login.jmx` | 50 线程 / 3 次 + 1 用户校验 | 并发登录 + 单用户带 token 查询意向历史 | 152 | 67.5ms | 72ms | 122ms | 28.1 req/s | 0% |

> 登录场景说明：系统对同一账号只保留一个有效 token，并发登录会互相覆盖 token。因此脚本将“50 并发登录”和“单用户登录后携带 `Authorization: Bearer` 查询”拆为两个串行线程组，最终结果 152 次请求全部通过。首轮混合执行时曾出现 146 次登录态校验失败，属于测试设计问题而非系统缺陷，调整后已消除。

### 4.3 关键观察

1. **响应时间**：商品浏览类只读接口在 100 并发下平均 5.2ms、P90 8ms，读路径与 MySQL 查询表现稳定；
2. **登录开销**：登录涉及密码校验与 token 写入数据库，平均 67.5ms，是三类场景中最高的，但 P90 仅 72ms，无明显抖动；
3. **稳定性**：2692 次请求 0 错误，未出现 5xx、超时或断言失败；
4. **瓶颈判断**：当前并发与数据量下未触及 CPU、内存或连接池瓶颈；若需生产容量评估，应提升并发、扩大数据量并分离压测机与压测网络。

---

## 5. 结论与建议

### 5.1 结论

- 端到端功能：买家注册/登录/浏览/搜索/详情/意向、卖家登录/商品管理/客户与分类管理主流程均可用，30 个用例全部通过；
- 接口性能：三个场景覆盖“冒烟—浏览—登录”核心链路，最大并发 100，全部请求成功，响应时间处于毫秒级；
- 部署验证：Nginx 静态托管与 `/api`、`/uploads` 反向代理工作正常，前后端及数据库联通无误。

### 5.2 建议

1. 为 `test_intent_queue_page_loads` 准备固定的意向队列测试数据，消除数据依赖导致的跳过；
2. 若继续压测，建议单独准备压测账号池，避免单账号 token 覆盖影响登录态链路；
3. 增加卖家发布商品、图片上传的 Selenium 用例，目前卖家侧以页面可用性验证为主；
4. 在 CI 中将 Selenium 与 JMeter 冒烟场景串成回归门禁，部署后自动执行。

---

## 6. 附件与产物

| 产物 | 路径 | 说明 |
|------|------|------|
| Selenium 用例 | [e2e/selenium](selenium) | pytest + Selenium 测试代码 |
| Selenium HTML 报告 | [report.html](selenium/report.html) | 30 通过 / 1 跳过，2 分 48 秒 |
| JMeter 脚本 | [e2e/jmeter](jmeter) | 3 个 `.jmx` 场景 |
| JMeter 原始结果 | [e2e/jmeter/results](jmeter/results) | `01-smoke.jtl`、`02-browse.jtl`、`03-login.jtl` |
| 部署手册 | [部署手册.md](../部署手册.md) | 环境搭建、启动与验证步骤 |

复跑命令：

```powershell
# Selenium
cd c:\Users\32827\Desktop\online-shop-2.0\e2e\selenium
$env:E2E_BASE_URL = "http://localhost:8088"
pytest -v

# JMeter（无界面模式，逐条执行）
cd c:\Users\32827\Desktop\online-shop-2.0\e2e
C:\Users\32827\apache-jmeter-5.6.3\bin\jmeter.bat -n -t jmeter\01-smoke.jmx  -l jmeter\results\01-smoke.jtl
C:\Users\32827\apache-jmeter-5.6.3\bin\jmeter.bat -n -t jmeter\02-browse.jmx -l jmeter\results\02-browse.jtl
C:\Users\32827\apache-jmeter-5.6.3\bin\jmeter.bat -n -t jmeter\03-login.jmx  -l jmeter\results\03-login.jtl
```
