import { beforeEach } from 'vitest'
import { vi } from 'vitest'

class LocalStorageMock {
  constructor() {
    this.store = {}
  }
  clear() {
    this.store = {}
  }
  getItem(key) {
    return this.store[key] || null
  }
  setItem(key, value) {
    this.store[key] = String(value)
  }
  removeItem(key) {
    delete this.store[key]
  }
}

beforeEach(() => {
  vi.clearAllMocks()
  if (typeof localStorage !== 'undefined' && localStorage instanceof LocalStorageMock === false) {
    localStorage.clear()
  }
})