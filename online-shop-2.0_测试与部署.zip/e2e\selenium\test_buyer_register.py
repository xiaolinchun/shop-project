import time
import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class TestBuyerRegister:

    def test_register_page_loads(self, driver, base_url):
        driver.get(f"{base_url}/buyer/register")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        h2 = driver.find_element(By.TAG_NAME, "h2")
        assert "买家注册" in h2.text

    def test_register_form_has_four_fields(self, driver, base_url):
        driver.get(f"{base_url}/buyer/register")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        inputs = driver.find_elements(By.CSS_SELECTOR, ".el-input__inner")
        assert len(inputs) >= 4

    def test_register_button_exists(self, driver, base_url):
        driver.get(f"{base_url}/buyer/register")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        buttons = driver.find_elements(By.TAG_NAME, "button")
        texts = [b.text.strip() for b in buttons]
        assert "注册" in texts

    def test_register_success_redirects_to_home(self, driver, base_url):
        unique = str(int(time.time()))
        driver.get(f"{base_url}/buyer/register")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )

        inputs = driver.find_elements(By.CSS_SELECTOR, ".el-input__inner")
        inputs[0].send_keys(f"e2e_buyer_{unique}")
        inputs[1].send_keys("Test@1234")
        inputs[2].send_keys("13800138000")
        inputs[3].send_keys("北京市朝阳区")

        buttons = driver.find_elements(By.TAG_NAME, "button")
        for btn in buttons:
            if btn.text.strip() == "注册":
                btn.click()
                break

        time.sleep(3)
        current_url = driver.current_url
        assert "/buyer/home" in current_url or "/buyer/login" in current_url