package com.shop.online_shop.service.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.shop.online_shop.common.BusinessException;
import com.shop.online_shop.entity.Intent;
import com.shop.online_shop.entity.Product;
import com.shop.online_shop.enums.ProductStatus;
import com.shop.online_shop.mapper.IntentMapper;
import com.shop.online_shop.mapper.ProductMapper;
import com.shop.online_shop.service.CategoryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.ArgumentMatchers;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProductServiceImplTest {

    @Mock
    private ProductMapper productMapper;

    @Mock
    private IntentMapper intentMapper;

    @Mock
    private CategoryService categoryService;

    private ProductServiceImpl productService;

    @BeforeEach
    void setUp() {
        productService = new ProductServiceImpl();
        ReflectionTestUtils.setField(productService, "baseMapper", productMapper);
        ReflectionTestUtils.setField(productService, "intentMapper", intentMapper);
        ReflectionTestUtils.setField(productService, "categoryService", categoryService);
    }

    @Test
    void unfreezeRejectsProductWithTradingIntent() {
        Product product = frozenProduct();
        when(productMapper.selectById(7)).thenReturn(product);
        when(intentMapper.selectCount(ArgumentMatchers.<Wrapper<Intent>>any())).thenReturn(1L);

        BusinessException exception = assertThrows(
                BusinessException.class,
                () -> productService.unfreeze(7, "seller-a"));

        assertEquals("商品存在进行中的交易，请先标记交易结果", exception.getMessage());
        assertEquals(ProductStatus.FROZEN, product.getStatus());
        verify(productMapper, never()).updateById(any(Product.class));
    }

    @Test
    void unfreezeRestoresProductWhenNoTradingIntentExists() {
        Product product = frozenProduct();
        when(productMapper.selectById(7)).thenReturn(product);
        when(intentMapper.selectCount(ArgumentMatchers.<Wrapper<Intent>>any())).thenReturn(0L);

        productService.unfreeze(7, "seller-a");

        assertEquals(ProductStatus.ONLINE, product.getStatus());
        verify(productMapper).updateById(product);
    }

    private Product frozenProduct() {
        Product product = new Product();
        product.setId(7);
        product.setSellerId("seller-a");
        product.setStatus(ProductStatus.FROZEN);
        return product;
    }
}
