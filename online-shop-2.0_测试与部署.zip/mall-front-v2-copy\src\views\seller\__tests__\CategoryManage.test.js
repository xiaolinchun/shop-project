import { describe, it, expect, beforeEach, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import ElementPlus from 'element-plus'
import CategoryManage from '@/views/seller/CategoryManage.vue'

vi.mock('@/api/seller', () => ({
  getSellerCategoryTree: vi.fn().mockResolvedValue({
    code: 200,
    data: [
      { id: 1, categoryName: '电子产品', parentId: 0, children: [
        { id: 101, categoryName: '电子配件', parentId: 1, productCount: 2 },
        { id: 102, categoryName: '手机', parentId: 1, productCount: 0 }
      ]},
      { id: 2, categoryName: '服装', parentId: 0, children: [
        { id: 201, categoryName: '男装', parentId: 2, productCount: 5 }
      ]},
      { id: 999, categoryName: '未分类', parentId: 0, children: [] }
    ]
  }),
  addCategory: vi.fn().mockResolvedValue({ code: 200 }),
  renameCategory: vi.fn().mockResolvedValue({ code: 200 }),
  delCategory: vi.fn().mockResolvedValue({ code: 200 })
}))

function createWrapper() {
  return mount(CategoryManage, {
    global: { plugins: [ElementPlus] }
  })
}

describe('分类管理 CategoryManage.vue - FR-A08', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe('页面渲染', () => {
    it('显示"分类管理"标题', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('分类管理')
    })

    it('包含"新增一级分类"按钮', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('新增一级分类')
    })
  })

  describe('FR-A08 分类树结构', () => {
    it('加载分类树后一级分类显示子分类商品数之和', async () => {
      const wrapper = createWrapper()
      await wrapper.vm.loadTree()
      expect(wrapper.vm.catTree.length).toBe(2)
    })

    it('过滤掉"未分类"系统分类', async () => {
      const wrapper = createWrapper()
      await wrapper.vm.loadTree()
      const names = wrapper.vm.catTree.map(c => c.categoryName)
      expect(names).not.toContain('未分类')
    })

    it('一级分类显示子分类', async () => {
      const wrapper = createWrapper()
      await wrapper.vm.loadTree()
      expect(wrapper.vm.catTree[0].children.length).toBe(2)
      expect(wrapper.vm.catTree[0].children[0].categoryName).toBe('电子配件')
    })

    it('parentCount 计算子分类商品数之和', async () => {
      const wrapper = createWrapper()
      await wrapper.vm.loadTree()
      const p = wrapper.vm.catTree[0]
      expect(wrapper.vm.parentCount(p)).toBe(2)
    })
  })

  describe('FR-A08 新增分类', () => {
    it('openAddRoot 设置 parentId=0', () => {
      const wrapper = createWrapper()
      wrapper.vm.openAddRoot()
      expect(wrapper.vm.addDialog.show).toBe(true)
      expect(wrapper.vm.addDialog.parentId).toBe(0)
      expect(wrapper.vm.addDialog.name).toBe('')
    })

    it('addChild 设置正确的 parentId', () => {
      const wrapper = createWrapper()
      wrapper.vm.addChild(1)
      expect(wrapper.vm.addDialog.show).toBe(true)
      expect(wrapper.vm.addDialog.parentId).toBe(1)
    })

    it('confirmAdd 调用 addCategory 并重置', async () => {
      const api = await import('@/api/seller')
      const wrapper = createWrapper()
      wrapper.vm.addDialog.show = true
      wrapper.vm.addDialog.parentId = 1
      wrapper.vm.addDialog.name = '新二级分类'
      await wrapper.vm.confirmAdd()
      expect(api.addCategory).toHaveBeenCalledWith({ parentId: 1, categoryName: '新二级分类' })
      expect(wrapper.vm.addDialog.show).toBe(false)
      expect(wrapper.vm.addDialog.name).toBe('')
    })
  })

  describe('FR-A08 重命名', () => {
    it('openRename 设置 renameDialog 状态', () => {
      const wrapper = createWrapper()
      wrapper.vm.openRename({ id: 5, categoryName: '旧名字' })
      expect(wrapper.vm.renameDialog.show).toBe(true)
      expect(wrapper.vm.renameDialog.id).toBe(5)
      expect(wrapper.vm.renameDialog.name).toBe('旧名字')
    })

    it('confirmRename 调用 renameCategory', async () => {
      const api = await import('@/api/seller')
      const wrapper = createWrapper()
      wrapper.vm.renameDialog.show = true
      wrapper.vm.renameDialog.id = 5
      wrapper.vm.renameDialog.name = '新名字'
      await wrapper.vm.confirmRename()
      expect(api.renameCategory).toHaveBeenCalledWith(5, '新名字')
      expect(wrapper.vm.renameDialog.show).toBe(false)
    })
  })

  describe('FR-A08 删除', () => {
    it('delCat 调用 delCategory', async () => {
      const api = await import('@/api/seller')
      const wrapper = createWrapper()
      await wrapper.vm.delCat(5)
      expect(api.delCategory).toHaveBeenCalledWith(5)
    })
  })
})