# Selenium E2E 测试运行说明

## 前置条件

1. **后端服务**已启动在 `http://localhost:8080`
2. **Chrome 浏览器**已安装（webdriver-manager 自动下载对应 chromedriver）
3. **Python >= 3.9** 已安装

## 安装依赖

```bash
cd e2e/selenium
pip install -r requirements.txt
```

## 运行测试

```bash
# 运行全部 E2E 测试
pytest

# 运行指定文件
pytest test_buyer_register.py -v

# 运行指定测试类
pytest test_buyer_login.py::TestBuyerLogin::test_login_success_jumps_to_home -v

# 生成 HTML 报告（已在 pytest.ini 配置默认启用）
pytest --html=report.html --self-contained-html
```

## 运行前确保数据准备

### 买家账号（需在数据库中存在）
| 用户名 | 密码 | 用途 |
|--------|------|------|
| `buyer1` | `12345678` | 登录成功测试、提交意向、查看历史 |

### 卖家账号
| 用户名 | 密码 | 用途 |
|--------|------|------|
| `seller1` | `12345678` | 卖家端所有页面访问 |

### 商品数据
- 至少有 1 个 ONLINE 状态商品，买家才能看到商品列表、点击详情、提交意向

## 测试文件清单

| 文件 | 测试内容 | 对应用例 |
|------|---------|---------|
| `test_home_select.py` | 首页选择页 | AA-01 |
| `test_buyer_register.py` | 买家注册 | AA-02 注册部分 |
| `test_buyer_login.py` | 买家登录 | AA-02 登录部分 |
| `test_buyer_browse.py` | 浏览商品、分类筛选、搜索 | AA-05、AA-07 |
| `test_buyer_intent.py` | 提交意向、未登录拦截、历史意向 | AA-03、AA-08 |
| `test_seller_product.py` | 卖家商品列表、发布商品 | AA-04、AA-06 |
| `test_seller_trade.py` | 意向队列、客户列表、分类管理、匿名归档 | AA-04、AA-09 |

## 故障排查

**ChromeDriver 问题**：如 webdriver-manager 下载失败，手动下载对应版本 chromedriver 并添加到 PATH。

**服务未启动**：Selenium 测试要求后端在 `http://localhost:8080` 运行，否则所有测试会因为 `driver.get()` 无法加载页面而失败。

**数据库缺少测试账号**：初始化 SQL 在 `deployment/mysql/01-online_shop.sql`，确保 `buyer1`/`seller1` 已创建。