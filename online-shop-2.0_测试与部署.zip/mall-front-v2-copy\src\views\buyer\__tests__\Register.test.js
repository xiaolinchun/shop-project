import { describe, it, expect, beforeEach, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import ElementPlus from 'element-plus'
import Register from '@/views/buyer/Register.vue'

vi.mock('@/api/buyer', () => ({
  buyerRegister: vi.fn().mockResolvedValue({ code: 200, data: 'token-xyz' })
}))

const mockSetBuyerToken = vi.fn()
vi.mock('@/stores/useUserStore', () => ({
  useUserStore: vi.fn(() => ({
    buyerToken: '',
    buyerInfo: null,
    setBuyerToken: mockSetBuyerToken
  }))
}))

const mockRouter = { push: vi.fn() }
vi.mock('vue-router', () => ({
  useRouter: () => mockRouter
}))

function createWrapper() {
  return mount(Register, {
    global: { plugins: [ElementPlus] }
  })
}

describe('买家注册 Register.vue - FR-A01', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    vi.clearAllMocks()
  })

  describe('页面渲染', () => {
    it('显示注册标题', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('买家注册')
    })

    it('包含注册按钮', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('注册')
    })

    it('包含去登录按钮', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('去登录')
    })

    it('提示密码至少8位', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('密码至少8位')
    })
  })

  describe('表单字段', () => {
    it('包含用户名、密码、手机号、默认交易地点 4 个字段', () => {
      const wrapper = createWrapper()
      const form = wrapper.vm.form
      expect(form).toHaveProperty('username')
      expect(form).toHaveProperty('password')
      expect(form).toHaveProperty('phone')
      expect(form).toHaveProperty('defaultTradeLocation')
    })

    it('所有字段初始为空', () => {
      const wrapper = createWrapper()
      expect(wrapper.vm.form.username).toBe('')
      expect(wrapper.vm.form.password).toBe('')
      expect(wrapper.vm.form.phone).toBe('')
      expect(wrapper.vm.form.defaultTradeLocation).toBe('')
    })
  })

  describe('表单校验', () => {
    it('用户名必填', () => {
      const wrapper = createWrapper()
      const rules = wrapper.vm.rules
      expect(rules.username.find(r => r.required)).toBeDefined()
    })

    it('密码至少 8 位', () => {
      const wrapper = createWrapper()
      const rules = wrapper.vm.rules
      expect(rules.password.find(r => r.min === 8)).toBeDefined()
      expect(rules.password.find(r => r.min === 8).message).toBe('密码至少8位')
    })

    it('手机号必填', () => {
      const wrapper = createWrapper()
      const rules = wrapper.vm.rules
      expect(rules.phone.find(r => r.required)).toBeDefined()
    })

    it('默认交易地点必填', () => {
      const wrapper = createWrapper()
      const rules = wrapper.vm.rules
      expect(rules.defaultTradeLocation.find(r => r.required)).toBeDefined()
    })
  })

  describe('需求规格一致性 FR-A01', () => {
    it('注册成功调用 buyerRegister -> setBuyerToken -> 跳转 /buyer/home', async () => {
      const api = await import('@/api/buyer')
      const wrapper = createWrapper()
      wrapper.vm.form.username = 'testuser'
      wrapper.vm.form.password = '12345678'
      wrapper.vm.form.phone = '13800138000'
      wrapper.vm.form.defaultTradeLocation = '北京中关村'
      wrapper.vm.formRef = { validate: vi.fn().mockResolvedValue(true) }
      await wrapper.vm.handleRegister()
      expect(api.buyerRegister).toHaveBeenCalled()
      expect(mockSetBuyerToken).toHaveBeenCalledWith('token-xyz', 'testuser')
      expect(mockRouter.push).toHaveBeenCalledWith('/buyer/home')
    })
  })
})