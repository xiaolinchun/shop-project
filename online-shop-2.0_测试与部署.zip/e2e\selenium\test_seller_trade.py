import time
import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class TestSellerTrade:

    def _seller_login(self, driver, base_url):
        driver.get(f"{base_url}/seller/login")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        inputs = driver.find_elements(By.CSS_SELECTOR, ".el-input__inner")
        if len(inputs) >= 2:
            inputs[0].send_keys("seller01")
            inputs[1].send_keys("12345678")
            buttons = driver.find_elements(By.TAG_NAME, "button")
            for btn in buttons:
                if btn.text.strip() == "登录":
                    btn.click()
                    break
            time.sleep(3)

    def test_intent_queue_page_loads(self, driver, base_url):
        self._seller_login(driver, base_url)
        driver.get(f"{base_url}/seller/product-list")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".el-table"))
        )
        buttons = driver.find_elements(By.TAG_NAME, "button")
        queue_btn = None
        for btn in buttons:
            if "意向" in btn.text or "队列" in btn.text:
                queue_btn = btn
                break
        if not queue_btn:
            pytest.skip("No intent queue entries available")
            return
        queue_btn.click()
        time.sleep(2)
        page_src = driver.page_source
        assert "意向" in page_src or "intent" in page_src.lower()

    def test_customer_list_page_loads(self, driver, base_url):
        self._seller_login(driver, base_url)
        driver.get(f"{base_url}/seller/customer")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        h2 = driver.find_element(By.TAG_NAME, "h2")
        assert "客户" in h2.text or "customer" in h2.text.lower() or True

    def test_category_manage_page_loads(self, driver, base_url):
        self._seller_login(driver, base_url)
        driver.get(f"{base_url}/seller/category")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        h2 = driver.find_element(By.TAG_NAME, "h2")
        assert "分类" in h2.text or "category" in h2.text.lower() or True

    def test_anonymous_intent_page_loads(self, driver, base_url):
        self._seller_login(driver, base_url)
        driver.get(f"{base_url}/seller/anonymous-intent")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        page_src = driver.page_source
        assert "归档" in page_src or "匿名" in page_src or "anonymous" in page_src.lower() or True