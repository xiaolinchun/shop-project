import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

BASE_URL = "http://localhost:5173"


@pytest.fixture(scope="function")
def driver():
    chrome_options = Options()
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--window-size=1920,1080")
    chrome_options.add_argument("--ignore-certificate-errors")

    try:
        service = Service(ChromeDriverManager().install())
        d = webdriver.Chrome(service=service, options=chrome_options)
    except Exception:
        d = webdriver.Chrome(options=chrome_options)

    d.implicitly_wait(5)
    yield d
    d.quit()


@pytest.fixture
def base_url():
    return BASE_URL