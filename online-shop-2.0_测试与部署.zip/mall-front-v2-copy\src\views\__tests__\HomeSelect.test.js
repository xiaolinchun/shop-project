import { describe, it, expect, beforeEach, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import ElementPlus from 'element-plus'
import HomeSelect from '@/views/HomeSelect.vue'

const mockRouter = { push: vi.fn() }

function createWrapper() {
  return mount(HomeSelect, {
    global: {
      plugins: [ElementPlus],
      config: {
        globalProperties: {
          $router: mockRouter
        }
      }
    }
  })
}

describe('首页选择 HomeSelect.vue', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe('页面渲染', () => {
    it('显示"商城系统"标题', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('商城系统')
    })

    it('包含"买家登录入口"按钮', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('买家登录入口')
    })

    it('包含"卖家登录入口"按钮', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('卖家登录入口')
    })
  })

  describe('路由跳转', () => {
    it('点击买家入口跳转到 /buyer/login', async () => {
      const wrapper = createWrapper()
      const buyerBtn = wrapper.findAll('button').find(b => b.text().includes('买家登录'))
      await buyerBtn.trigger('click')
      expect(mockRouter.push).toHaveBeenCalledWith('/buyer/login')
    })

    it('点击卖家入口跳转到 /seller/login', async () => {
      const wrapper = createWrapper()
      const sellerBtn = wrapper.findAll('button').find(b => b.text().includes('卖家登录'))
      await sellerBtn.trigger('click')
      expect(mockRouter.push).toHaveBeenCalledWith('/seller/login')
    })
  })
})