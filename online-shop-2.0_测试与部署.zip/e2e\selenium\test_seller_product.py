import time
import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class TestSellerLogin:

    def _seller_login(self, driver, base_url):
        driver.get(f"{base_url}/seller/login")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        inputs = driver.find_elements(By.CSS_SELECTOR, ".el-input__inner")
        if len(inputs) >= 2:
            inputs[0].send_keys("seller01")
            inputs[1].send_keys("12345678")
            buttons = driver.find_elements(By.TAG_NAME, "button")
            for btn in buttons:
                if btn.text.strip() == "登录":
                    btn.click()
                    break
            time.sleep(3)

    def test_seller_product_list_page_loads(self, driver, base_url):
        self._seller_login(driver, base_url)
        driver.get(f"{base_url}/seller/product-list")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".el-table"))
        )
        page_src = driver.page_source
        assert "商品" in page_src or "发布新商品" in page_src

    def test_seller_product_list_has_publish_button(self, driver, base_url):
        self._seller_login(driver, base_url)
        driver.get(f"{base_url}/seller/product-list")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".el-table"))
        )
        buttons = driver.find_elements(By.TAG_NAME, "button")
        texts = [b.text.strip() for b in buttons]
        assert any("发布" in t for t in texts)

    def test_seller_product_list_has_filter(self, driver, base_url):
        self._seller_login(driver, base_url)
        driver.get(f"{base_url}/seller/product-list")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".el-table"))
        )
        page_src = driver.page_source
        assert "状态" in page_src or "筛选" in page_src or "el-select" in driver.page_source

    def test_seller_publish_product_page_loads(self, driver, base_url):
        self._seller_login(driver, base_url)
        driver.get(f"{base_url}/seller/publish")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        h2 = driver.find_element(By.TAG_NAME, "h2")
        assert "发布" in h2.text or "商品" in h2.text

    def test_seller_publish_form_has_fields(self, driver, base_url):
        self._seller_login(driver, base_url)
        driver.get(f"{base_url}/seller/publish")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        page_src = driver.page_source
        assert "价格" in page_src or "库存" in page_src or "分类" in page_src