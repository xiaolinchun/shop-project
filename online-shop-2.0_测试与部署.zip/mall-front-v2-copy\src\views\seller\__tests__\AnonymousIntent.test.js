import { describe, it, expect, beforeEach, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import ElementPlus from 'element-plus'
import AnonymousIntent from '@/views/seller/AnonymousIntent.vue'

vi.mock('@/api/seller', () => ({
  getAnonymousIntentList: vi.fn().mockResolvedValue({
    code: 200,
    data: {
      list: [
        { id: 501, productId: 1, productName: '早期商品A', buyerName: '张三', phone: '13800000000', status: 'ARCHIVED', createdAt: '2026-09-01' }
      ],
      total: 1
    }
  })
}))

function createWrapper() {
  return mount(AnonymousIntent, {
    global: { plugins: [ElementPlus] }
  })
}

describe('存量匿名意向归档 AnonymousIntent.vue - RA5', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe('页面渲染', () => {
    it('显示归档标题并注明只读', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('存量匿名意向归档')
      expect(wrapper.text()).toContain('只读')
    })
  })

  describe('RA5 表格列', () => {
    it('表格包含全部必要列', async () => {
      const wrapper = createWrapper()
      await wrapper.vm.load()
      const text = wrapper.text()
      expect(text).toContain('意向ID')
      expect(text).toContain('商品ID')
      expect(text).toContain('商品快照')
      expect(text).toContain('旧姓名')
      expect(text).toContain('旧电话')
      expect(text).toContain('状态')
      expect(text).toContain('创建时间')
    })

    it('无操作列 - 符合只读归档要求', async () => {
      const wrapper = createWrapper()
      await wrapper.vm.load()
      expect(wrapper.text()).not.toContain('操作')
      expect(wrapper.text()).not.toContain('按钮')
    })
  })

  describe('初始状态', () => {
    it('query 默认 page=1, size=10', () => {
      const wrapper = createWrapper()
      expect(wrapper.vm.query.page).toBe(1)
      expect(wrapper.vm.query.size).toBe(10)
    })
  })
})