import { describe, it, expect, beforeEach, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import ElementPlus from 'element-plus'
import BuyerLogin from '@/views/buyer/Login.vue'

const mockBuyerLogin = vi.fn().mockResolvedValue({ code: 200, data: 'token-abc' })
vi.mock('@/stores/useUserStore', () => ({
  useUserStore: vi.fn(() => ({
    buyerToken: '',
    buyerInfo: null,
    buyerLogin: mockBuyerLogin
  }))
}))

const mockRouter = { push: vi.fn() }
vi.mock('vue-router', () => ({
  useRouter: () => mockRouter
}))

function createWrapper() {
  return mount(BuyerLogin, {
    global: { plugins: [ElementPlus] }
  })
}

describe('买家登录 BuyerLogin.vue - FR-A02', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    vi.clearAllMocks()
  })

  describe('页面渲染', () => {
    it('显示"买家登录"标题', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('买家登录')
    })

    it('显示账号和密码输入框', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('账号')
      expect(wrapper.text()).toContain('密码')
    })

    it('包含登录按钮', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('登录')
    })

    it('包含注册链接', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('还未注册')
      expect(wrapper.text()).toContain('注册')
    })

    it('包含返回选择页按钮', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('返回选择页')
    })
  })

  describe('初始状态', () => {
    it('表单初始为空', () => {
      const wrapper = createWrapper()
      expect(wrapper.vm.form.username).toBe('')
      expect(wrapper.vm.form.password).toBe('')
    })

    it('loading 初始为 false', () => {
      const wrapper = createWrapper()
      expect(wrapper.vm.loading).toBe(false)
    })
  })

  describe('登录流程', () => {
    it('登录成功后跳转到 /buyer/home', async () => {
      const wrapper = createWrapper()
      wrapper.vm.form.username = 'testuser'
      wrapper.vm.form.password = '12345678'
      await wrapper.vm.handleLogin()
      expect(mockBuyerLogin).toHaveBeenCalledWith({ username: 'testuser', password: '12345678' })
      expect(mockRouter.push).toHaveBeenCalledWith('/buyer/home')
    })

    it('登录成功后 loading 变回 false', async () => {
      const wrapper = createWrapper()
      wrapper.vm.form.username = 'testuser'
      wrapper.vm.form.password = '12345678'
      await wrapper.vm.handleLogin()
      expect(wrapper.vm.loading).toBe(false)
    })
  })
})