import { describe, it, expect, beforeEach, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import ElementPlus from 'element-plus'
import MyIntent from '@/views/buyer/MyIntent.vue'

vi.mock('@/api/buyer', () => ({
  getBuyerIntentHistory: vi.fn().mockResolvedValue({
    code: 200,
    data: {
      list: [
        { id: 1, productName: '无线鼠标', createdAt: '2026-11-05', result: 'SUCCESS', resultAt: '2026-11-06' },
        { id: 2, productName: '机械键盘', createdAt: '2026-11-06', result: 'FAILURE', resultAt: '2026-11-07' }
      ],
      total: 2
    }
  })
}))

vi.mock('vue-router', () => ({
  useRouter: () => ({ push: vi.fn() })
}))

function createWrapper() {
  return mount(MyIntent, {
    global: { plugins: [ElementPlus] }
  })
}

async function mountAndWait() {
  const wrapper = createWrapper()
  await new Promise(r => setTimeout(r, 50))
  return wrapper
}

describe('买家历史意向 MyIntent.vue - FR-A04', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe('页面渲染', () => {
    it('显示"我的历史意向记录"标题', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('我的历史意向记录')
    })

    it('显示返回首页按钮', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('返回首页')
    })
  })

  describe('FR-A04 表格列', () => {
    it('表格包含全部必要列', async () => {
      const wrapper = await mountAndWait()
      const text = wrapper.text()
      expect(text).toContain('商品名称')
      expect(text).toContain('下单时间')
      expect(text).toContain('交易结果')
      expect(text).toContain('结果时间')
    })
  })

  describe('FR-A04 数据渲染', () => {
    it('显示意向历史数据', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('无线鼠标')
      expect(wrapper.text()).toContain('机械键盘')
      expect(wrapper.text()).toContain('2026-11-05')
      expect(wrapper.text()).toContain('SUCCESS')
    })
  })

  describe('初始状态', () => {
    it('query 默认 page=1, size=10', () => {
      const wrapper = createWrapper()
      expect(wrapper.vm.query.page).toBe(1)
      expect(wrapper.vm.query.size).toBe(10)
    })
  })
})