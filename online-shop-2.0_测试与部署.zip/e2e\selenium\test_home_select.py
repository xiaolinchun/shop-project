import time
import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class TestHomeSelect:

    def test_home_page_loads(self, driver, base_url):
        driver.get(f"{base_url}/")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h1"))
        )
        h1 = driver.find_element(By.TAG_NAME, "h1")
        assert "商城" in h1.text

    def test_buyer_entry_button_exists(self, driver, base_url):
        driver.get(f"{base_url}/")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h1"))
        )
        buttons = driver.find_elements(By.TAG_NAME, "button")
        texts = [b.text.strip() for b in buttons]
        assert any("买家" in t for t in texts)

    def test_seller_entry_button_exists(self, driver, base_url):
        driver.get(f"{base_url}/")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h1"))
        )
        buttons = driver.find_elements(By.TAG_NAME, "button")
        texts = [b.text.strip() for b in buttons]
        assert any("卖家" in t for t in texts)

    def test_click_buyer_entry_navigates_to_login(self, driver, base_url):
        driver.get(f"{base_url}/")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h1"))
        )
        buttons = driver.find_elements(By.TAG_NAME, "button")
        for btn in buttons:
            if "买家" in btn.text:
                btn.click()
                break
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        assert "/buyer/login" in driver.current_url

    def test_click_seller_entry_navigates_to_login(self, driver, base_url):
        driver.get(f"{base_url}/")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h1"))
        )
        buttons = driver.find_elements(By.TAG_NAME, "button")
        for btn in buttons:
            if "卖家" in btn.text:
                btn.click()
                break
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        assert "/seller/login" in driver.current_url