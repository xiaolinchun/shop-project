import { describe, it, expect, beforeEach, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import ElementPlus from 'element-plus'
import CustomerList from '@/views/seller/CustomerList.vue'

vi.mock('@/api/seller', () => ({
  getCustomerList: vi.fn().mockResolvedValue({
    code: 200,
    data: {
      list: [
        { username: 'buyer1', phone: '13800138000', defaultTradeLocation: '北京海淀', createdAt: '2026-10-01' },
        { username: 'buyer2', phone: '13900139000', defaultTradeLocation: '', createdAt: '2026-10-15' }
      ],
      total: 2
    }
  }),
  getCustomerHistory: vi.fn().mockResolvedValue({
    code: 200,
    data: {
      list: [
        { productName: '无线鼠标', createdAt: '2026-11-01', result: 'SUCCESS', resultAt: '2026-11-02' }
      ],
      total: 1
    }
  })
}))

function createWrapper() {
  return mount(CustomerList, {
    global: { plugins: [ElementPlus] }
  })
}

describe('客户列表 CustomerList.vue - FR-A11', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe('页面渲染', () => {
    it('显示"全部客户列表"标题', () => {
      const wrapper = createWrapper()
      expect(wrapper.text()).toContain('全部客户列表')
    })
  })

  describe('FR-A11 表格列', () => {
    it('表格包含全部必要列', async () => {
      const wrapper = createWrapper()
      await wrapper.vm.loadList()
      const text = wrapper.text()
      expect(text).toContain('用户名')
      expect(text).toContain('手机号')
      expect(text).toContain('默认交易地点')
      expect(text).toContain('注册时间')
      expect(text).toContain('操作')
    })

    it('默认交易地点为空时显示"未设置"', async () => {
      const wrapper = createWrapper()
      await wrapper.vm.loadList()
      expect(wrapper.text()).toContain('未设置')
    })

    it('每行有"查看该客户购买历史"按钮', async () => {
      const wrapper = createWrapper()
      await wrapper.vm.loadList()
      expect(wrapper.text()).toContain('查看该客户购买历史')
    })
  })

  describe('FR-A11 购买历史弹窗', () => {
    it('openHistory 打开弹窗并加载历史', async () => {
      const api = await import('@/api/seller')
      const wrapper = createWrapper()
      await wrapper.vm.openHistory('buyer1')
      expect(wrapper.vm.historyDialog.show).toBe(true)
      expect(api.getCustomerHistory).toHaveBeenCalledWith('buyer1', { page: 1, size: 50 })
      expect(wrapper.vm.historyList.length).toBe(1)
    })
  })

  describe('初始状态', () => {
    it('query 默认 page=1, size=10', () => {
      const wrapper = createWrapper()
      expect(wrapper.vm.query.page).toBe(1)
      expect(wrapper.vm.query.size).toBe(10)
    })
  })
})