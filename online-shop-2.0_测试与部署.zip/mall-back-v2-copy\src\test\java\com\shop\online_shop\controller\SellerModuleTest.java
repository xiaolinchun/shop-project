package com.shop.online_shop.controller;

import com.shop.online_shop.auth.SellerAuthInterceptor;
import com.shop.online_shop.common.GlobalExceptionHandler;
import com.shop.online_shop.dto.seller.AddCategoryDTO;
import com.shop.online_shop.dto.seller.PublishProductDTO;
import com.shop.online_shop.entity.Product;
import com.shop.online_shop.service.BuyerAccountService;
import com.shop.online_shop.service.CategoryService;
import com.shop.online_shop.service.IntentService;
import com.shop.online_shop.service.ProductService;
import com.shop.online_shop.service.SellerService;
import com.shop.online_shop.vo.PageResult;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.executable.ExecutableValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Set;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class SellerModuleTest {

    private final ProductService productService = mock(ProductService.class);
    private final IntentService intentService = mock(IntentService.class);
    private final CategoryService categoryService = mock(CategoryService.class);
    private final BuyerAccountService buyerAccountService = mock(BuyerAccountService.class);
    private final SellerService sellerService = mock(SellerService.class);
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        SellerController controller = new SellerController();
        ReflectionTestUtils.setField(controller, "productService", productService);
        ReflectionTestUtils.setField(controller, "intentService", intentService);
        ReflectionTestUtils.setField(controller, "categoryService", categoryService);
        ReflectionTestUtils.setField(controller, "buyerAccountService", buyerAccountService);
        ReflectionTestUtils.setField(controller, "sellerService", sellerService);

        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    @Test
    void sellerLoginReturnsToken() throws Exception {
        when(sellerService.login(any())).thenReturn("seller-token");

        mockMvc.perform(post("/api/seller/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"username":"seller-a","password":"password123"}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data").value("seller-token"));
    }

    @Test
    void publishPassesSellerIdentityAndProductData() throws Exception {
        mockMvc.perform(post("/api/seller/product/publish")
                        .requestAttr(SellerAuthInterceptor.ATTR_SELLER_USERNAME, "seller-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"Book","description":"Description","imageUrls":[],"price":12.50,"categoryId":4,"stock":3}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200));

        verify(productService).publish(any(PublishProductDTO.class), eq("seller-a"));
    }

    @Test
    void sellerProductListUsesSellerAndPagination() throws Exception {
        when(productService.listSellerProducts("seller-a", "ONLINE", 2, 5))
                .thenReturn(new PageResult<>(List.<Product>of(), 0, 2, 5));

        mockMvc.perform(get("/api/seller/product/list")
                        .requestAttr(SellerAuthInterceptor.ATTR_SELLER_USERNAME, "seller-a")
                        .param("status", "ONLINE")
                        .param("page", "2")
                        .param("size", "5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.page").value(2));
    }

    @Test
    void stockAndCategoryOperationsPassSellerIdentity() throws Exception {
        mockMvc.perform(post("/api/seller/product/stock/{id}", 7)
                        .requestAttr(SellerAuthInterceptor.ATTR_SELLER_USERNAME, "seller-a")
                        .param("stock", "0"))
                .andExpect(status().isOk());
        mockMvc.perform(post("/api/seller/product/recategory/{id}", 7)
                        .requestAttr(SellerAuthInterceptor.ATTR_SELLER_USERNAME, "seller-a")
                        .param("categoryId", "4"))
                .andExpect(status().isOk());

        verify(productService).updateStock(7, 0, "seller-a");
        verify(productService).changeCategory(7, 4, "seller-a");
    }

    @Test
    void negativeStockViolatesTheEndpointConstraint() throws NoSuchMethodException {
        Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
        ExecutableValidator executableValidator = validator.forExecutables();
        Method method = SellerController.class.getMethod(
                "updateStock", Integer.class, Integer.class, HttpServletRequest.class);

        Set<ConstraintViolation<SellerController>> violations = executableValidator.validateParameters(
                new SellerController(),
                method,
                new Object[]{7, -1, new MockHttpServletRequest()});

        assertTrue(
                violations.stream().anyMatch(violation -> "库存不能为负".equals(violation.getMessage())));
    }

    @Test
    void categoryCanBeAddedAndDeleted() throws Exception {
        mockMvc.perform(post("/api/seller/category")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"parentId":0,"categoryName":"Electronics"}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200));
        mockMvc.perform(delete("/api/seller/category/{id}", 3))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200));

        verify(categoryService).addCategory(any(AddCategoryDTO.class));
        verify(categoryService).deleteCategory(3);
    }

    @Test
    void tradeResultIsForwardedToIntentService() throws Exception {
        mockMvc.perform(post("/api/seller/trade/mark")
                        .requestAttr(SellerAuthInterceptor.ATTR_SELLER_USERNAME, "seller-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"intentId":15,"operate":"SUCCESS"}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200));

        verify(intentService).markTrade(15, "SUCCESS", "seller-a");
    }

    @Test
    void customerHistoryRequiresAnExistingCustomer() throws Exception {
        when(buyerAccountService.getByUsername("buyer-a")).thenReturn(null);

        mockMvc.perform(get("/api/seller/customer/{username}/history", "buyer-a"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(500))
                .andExpect(jsonPath("$.msg").value("顾客不存在"));

        verify(intentService, org.mockito.Mockito.never())
                .getCustomerHistory(any(), any(), any());
    }
}
