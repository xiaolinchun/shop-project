import time
import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class TestBuyerBrowse:

    def test_home_page_loads_product_list(self, driver, base_url):
        driver.get(f"{base_url}/buyer/home")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        h2 = driver.find_element(By.TAG_NAME, "h2")
        assert "商品" in h2.text

    def test_home_page_has_search_and_reset(self, driver, base_url):
        driver.get(f"{base_url}/buyer/home")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        buttons = driver.find_elements(By.TAG_NAME, "button")
        texts = [b.text.strip() for b in buttons]
        assert any("搜索" in t for t in texts)
        assert any("重置" in t for t in texts)

    def test_home_page_has_pagination(self, driver, base_url):
        driver.get(f"{base_url}/buyer/home")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "el-pagination"))
        )
        pag = driver.find_elements(By.CLASS_NAME, "el-pagination")
        assert len(pag) >= 1

    def test_category_filter_exists(self, driver, base_url):
        driver.get(f"{base_url}/buyer/home")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        selects = driver.find_elements(By.CLASS_NAME, "el-select")
        assert len(selects) >= 1

    def test_click_product_detail(self, driver, base_url):
        driver.get(f"{base_url}/buyer/home")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        time.sleep(1)
        buttons = driver.find_elements(By.TAG_NAME, "button")
        for btn in buttons:
            if "详情" in btn.text or "查看" in btn.text:
                btn.click()
                break
        else:
            pytest.skip("No product detail buttons found")
        time.sleep(2)
        assert "/buyer/detail" in driver.current_url

    def test_search_product_by_keyword(self, driver, base_url):
        driver.get(f"{base_url}/buyer/home")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "h2"))
        )
        time.sleep(1)
        inputs = driver.find_elements(By.CSS_SELECTOR, ".el-input__inner")
        if len(inputs) >= 1:
            inputs[0].clear()
            inputs[0].send_keys("鼠标")
            buttons = driver.find_elements(By.TAG_NAME, "button")
            for btn in buttons:
                if "搜索" in btn.text:
                    btn.click()
                    break
            time.sleep(2)
            h2 = driver.find_element(By.TAG_NAME, "h2")
            assert "商品" in h2.text
        else:
            pytest.skip("No search input found")