import { describe, it, expect, beforeEach, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import ElementPlus from 'element-plus'
import IntentQueue from '@/views/seller/IntentQueue.vue'

vi.mock('@/api/seller', () => ({
  getIntentList: vi.fn().mockResolvedValue({
    code: 200,
    data: [
      { id: 10, buyerUsername: 'buyer1', status: 'QUEUED', createdAt: '2026-11-05 10:00', updatedAt: '2026-11-05 10:00' },
      { id: 11, buyerUsername: 'buyer2', status: 'TRADING', createdAt: '2026-11-05 10:01', updatedAt: '2026-11-05 10:02' },
      { id: 12, buyerUsername: 'buyer3', status: 'QUEUED', createdAt: '2026-11-05 10:03', updatedAt: '2026-11-05 10:03' }
    ]
  }),
  tradeMark: vi.fn().mockResolvedValue({ code: 200 })
}))

const mockRouter = { push: vi.fn() }
const mockRoute = { params: { productId: '5' }, query: { productName: '无线鼠标' } }
vi.mock('vue-router', () => ({
  useRouter: () => mockRouter,
  useRoute: () => mockRoute
}))

function createWrapper() {
  return mount(IntentQueue, {
    global: { plugins: [ElementPlus] }
  })
}

async function mountAndWait() {
  const wrapper = createWrapper()
  await new Promise(r => setTimeout(r, 50))
  return wrapper
}

describe('卖家意向队列 IntentQueue.vue - RA1/RA2', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe('页面渲染', () => {
    it('显示商品名和商品Id', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain("商品 '无线鼠标'")
      expect(wrapper.text()).toContain('商品Id:5')
    })

    it('显示返回商品列表按钮', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('返回商品列表')
    })
  })

  describe('RA1 意向队列表格列', () => {
    it('表格包含全部列', async () => {
      const wrapper = await mountAndWait()
      const text = wrapper.text()
      expect(text).toContain('意向ID')
      expect(text).toContain('买家用户名')
      expect(text).toContain('意向状态')
      expect(text).toContain('创建排队时间')
      expect(text).toContain('更新时间')
    })
  })

  describe('RA1 队列数据渲染', () => {
    it('显示意向列表数据', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('buyer1')
      expect(wrapper.text()).toContain('buyer2')
      expect(wrapper.text()).toContain('buyer3')
    })
  })

  describe('RA2 交易规则操作按钮', () => {
    it('QUEUED 且为队首时显示 START 按钮', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('START进入交易')
    })

    it('TRADING 显示 SUCCESS、FAILURE、RE_QUEUE 按钮', async () => {
      const wrapper = await mountAndWait()
      expect(wrapper.text()).toContain('SUCCESS交易成功')
      expect(wrapper.text()).toContain('FAILURE作废')
      expect(wrapper.text()).toContain('RE_QUEUE重新排队(队尾)')
    })
  })

  describe('初始值', () => {
    it('productId 来自路由 params', () => {
      const wrapper = createWrapper()
      expect(wrapper.vm.productId).toBe(5)
    })

    it('productName 来自路由 query', () => {
      const wrapper = createWrapper()
      expect(wrapper.vm.productName).toBe('无线鼠标')
    })
  })
})